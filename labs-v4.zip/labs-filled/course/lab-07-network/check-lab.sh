#!/usr/bin/env bash

set -u

SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
REPORT="$SCRIPT_DIR/assets/network-report.txt"
NODE="$(id -un)-node"
ERRORS=0

pass() { printf '  [OK] %s\n' "$1"; }
fail() { printf '  [ПОМИЛКА] %s\n' "$1"; ERRORS=$((ERRORS + 1)); }

NODE_READY=0
if ! command -v lxc >/dev/null 2>&1; then
    fail "команда lxc недоступна; слід звернутися до викладача"
elif ! lxc list >/dev/null 2>&1; then
    fail "немає доступу до lxc: сеанс не має членства в групі lxd; слід вийти із сервера й увійти знову"
elif ! lxc info "$NODE" >/dev/null 2>&1; then
    fail "контейнер $NODE не знайдено; слід звернутися до викладача"
else
    STATUS=$(lxc info "$NODE" | awk '/^Status:/ { print $2 }')
    if [ "$STATUS" = "RUNNING" ]; then
        pass "контейнер $NODE запущено"
        NODE_READY=1
    else
        fail "контейнер $NODE не запущено (стан: ${STATUS:-невідомий})"
    fi
fi

if [ "$NODE_READY" -eq 1 ]; then
    ACTUAL_MAC=$(lxc exec "$NODE" -- cat /sys/class/net/eth0/address 2>/dev/null | tr 'A-F' 'a-f')
    REPORT_MAC=""
    if [ -f "$REPORT" ]; then
        REPORT_MAC=$(grep '^MAC-адреса інтерфейсу контейнера:' "$REPORT" \
            | grep -Eio '([0-9a-f]{2}:){5}[0-9a-f]{2}' | head -n 1 | tr 'A-F' 'a-f')
    fi
    if [ -n "$ACTUAL_MAC" ] && [ "$REPORT_MAC" = "$ACTUAL_MAC" ]; then
        pass "MAC-адреса контейнера у звіті збігається з фактичною"
    else
        fail "MAC-адреса контейнера у звіті (${REPORT_MAC:-не вказано}) не збігається з фактичною"
    fi

    BRIDGE_ADDR=$(ip -4 -o addr show dev lxdbr0 2>/dev/null | awk '{ split($4, a, "/"); print a[1]; exit }')
    SERVER_ADDR=$(lxc exec "$NODE" -- getent hosts server 2>/dev/null | awk '{ print $1; exit }')
    if [ -z "$SERVER_ADDR" ]; then
        fail "у контейнері ім'я server не визначається засобами системи"
    elif [ "$SERVER_ADDR" = "$BRIDGE_ADDR" ]; then
        pass "у контейнері ім'я server відповідає адресі $SERVER_ADDR"
    else
        fail "у контейнері ім'я server відповідає адресі $SERVER_ADDR, а не адресі сервера в мережі lxdbr0"
    fi
fi

if [ -f "$REPORT" ]; then
    pass "файл network-report.txt існує"
    if grep -q '<заповнити>' "$REPORT"; then
        fail "у звіті залишилися поля <заповнити>"
    else
        pass "усі поля звіту заповнено"
    fi
else
    fail "не знайдено $REPORT"
fi

if [ "$ERRORS" -eq 0 ]; then
    printf '\nУсі автоматичні перевірки пройдено.\n'
else
    printf '\nКількість невиконаних перевірок: %s\n' "$ERRORS"
    exit 1
fi
