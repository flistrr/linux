#!/usr/bin/env bash

printf 'Навчальне резервне копіювання виконано.\n'
