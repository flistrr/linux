#!/usr/bin/env python3

import os
import signal
import sys
import time


def finish(signum: int, _frame: object) -> None:
    names = {
        signal.SIGINT: "SIGINT",
        signal.SIGTERM: "SIGTERM",
    }
    name = names.get(signum, str(signum))
    print(f"Процес {os.getpid()}: отримано {name}", flush=True)
    print(f"Процес {os.getpid()}: коректне завершення", flush=True)
    raise SystemExit(130 if signum == signal.SIGINT else 0)


signal.signal(signal.SIGINT, finish)
signal.signal(signal.SIGTERM, finish)

print(
    f"Процес запущено: PID={os.getpid()}, PPID={os.getppid()}",
    flush=True,
)

iteration = 0
while True:
    iteration += 1
    print(f"stdout: ітерація {iteration}", flush=True)
    if iteration % 3 == 0:
        print(
            f"stderr: діагностичне повідомлення {iteration}",
            file=sys.stderr,
            flush=True,
        )
    time.sleep(1)
