#!/usr/bin/env bash

set -u

SCRIPT_DIR=${LAB_DIR:-$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)}
REPORT="$SCRIPT_DIR/assets/ssh-report.txt"
PARAMS_REL="ros2_ws/src/robot_pkg/config/params.yaml"
PARAMS="$SCRIPT_DIR/assets/$PARAMS_REL"
PARAMS_ORIG="/home/shared/labs/lab-09-ssh/assets/$PARAMS_REL"
ADMIN_HOME="/home/admin1"
NODE="$(id -un)-node"
ERRORS=0

pass() { printf '  [OK] %s\n' "$1"; }
fail() { printf '  [ПОМИЛКА] %s\n' "$1"; ERRORS=$((ERRORS + 1)); }

node() { lxc exec "$NODE" -- "$@"; }

NODE_READY=0
if ! command -v lxc >/dev/null 2>&1; then
    fail "команда lxc недоступна; слід звернутися до викладача"
elif ! lxc list >/dev/null 2>&1; then
    fail "немає доступу до lxc: сеанс не має членства в групі lxd; слід вийти із сервера й увійти знову"
elif ! lxc info "$NODE" >/dev/null 2>&1; then
    fail "контейнер $NODE не знайдено; слід звернутися до викладача"
else
    STATUS=$(lxc info "$NODE" | awk '/^Status:/ { print $2 }')
    if [ "$STATUS" = "RUNNING" ]; then
        pass "контейнер $NODE запущено"
        NODE_READY=1
    else
        fail "контейнер $NODE не запущено (стан: ${STATUS:-невідомий})"
    fi
fi

if [ "$NODE_READY" -eq 1 ]; then
    if ! node id admin1 >/dev/null 2>&1; then
        fail "у контейнері немає користувача admin1"
    elif node id -nG admin1 2>/dev/null | tr ' ' '\n' | grep -qx sudo; then
        pass "користувач admin1 існує й входить до групи sudo"
    else
        fail "користувач admin1 не входить до групи sudo"
    fi

    NODE_ADDR=$(node ip -4 -o addr show dev eth0 2>/dev/null | awk '{ split($4, a, "/"); print a[1]; exit }')
    if [ -z "$NODE_ADDR" ]; then
        fail "не вдалося визначити IPv4-адресу контейнера"
    elif [ -f "$HOME/.ssh/known_hosts" ] && ssh-keygen -F "$NODE_ADDR" -f "$HOME/.ssh/known_hosts" >/dev/null 2>&1; then
        pass "~/.ssh/known_hosts містить запис для $NODE_ADDR"
    else
        fail "у ~/.ssh/known_hosts немає запису для адреси контейнера $NODE_ADDR"
    fi

    AUTH_KEYS=$(node cat "$ADMIN_HOME/.ssh/authorized_keys" 2>/dev/null)
    KEY_FOUND=0
    for pub in "$HOME"/.ssh/*.pub; do
        [ -f "$pub" ] || continue
        body=$(awk '{ print $2; exit }' "$pub")
        if [ -n "$body" ] && printf '%s\n' "$AUTH_KEYS" | grep -qF -- "$body"; then
            KEY_FOUND=1
            break
        fi
    done
    if [ "$KEY_FOUND" -eq 1 ]; then
        pass "публічний ключ із сервера є в authorized_keys користувача admin1"
    else
        fail "у $ADMIN_HOME/.ssh/authorized_keys немає жодного публічного ключа з ~/.ssh на сервері"
    fi

    for path in "$ADMIN_HOME/.ssh" "$ADMIN_HOME/.ssh/authorized_keys"; do
        mode=$(node stat -c '%a' "$path" 2>/dev/null)
        if [ -z "$mode" ]; then
            fail "у контейнері не знайдено $path"
        elif (( 8#$mode & 8#022 )); then
            fail "$path має права $mode: запис дозволено групі або іншим"
        else
            pass "$path має права $mode"
        fi
    done

    SSHD_T=$(node sshd -T 2>/dev/null)
    for setting in "permitrootlogin no" "passwordauthentication no"; do
        if printf '%s\n' "$SSHD_T" | grep -qx "$setting"; then
            pass "чинне значення сервера SSH: $setting"
        else
            actual=$(printf '%s\n' "$SSHD_T" | grep "^${setting% *} " | head -n 1)
            fail "очікувалося $setting, чинне значення: ${actual:-не визначено}"
        fi
    done

    if node test -d "$ADMIN_HOME/ros2_ws/src/robot_pkg"; then
        pass "каталог $ADMIN_HOME/ros2_ws/src/robot_pkg існує"
        for dir in build install log; do
            if node test -e "$ADMIN_HOME/ros2_ws/$dir"; then
                fail "у $ADMIN_HOME/ros2_ws є каталог $dir, який не мав передаватися"
            fi
        done
        LOCAL_SUM=$(sha256sum "$PARAMS" 2>/dev/null | awk '{ print $1 }')
        NODE_SUM=$(node sha256sum "$ADMIN_HOME/$PARAMS_REL" 2>/dev/null | awk '{ print $1 }')
        if [ -z "$LOCAL_SUM" ]; then
            fail "не знайдено $PARAMS"
        elif [ "$LOCAL_SUM" = "$NODE_SUM" ]; then
            pass "файл параметрів у контейнері збігається із серверною копією"
        else
            fail "файл параметрів у контейнері відрізняється від серверної копії: синхронізацію не завершено"
        fi
        if [ -f "$PARAMS_ORIG" ] && cmp -s "$PARAMS" "$PARAMS_ORIG"; then
            fail "файл параметрів на сервері не змінено (завдання 5, крок 3)"
        fi
    else
        fail "у контейнері не знайдено $ADMIN_HOME/ros2_ws/src/robot_pkg"
    fi
fi

if [ -f "$REPORT" ]; then
    pass "файл ssh-report.txt існує"
    if grep -q '<заповнити>' "$REPORT"; then
        fail "у звіті залишилися поля <заповнити>"
    else
        pass "усі поля звіту заповнено"
    fi
else
    fail "не знайдено $REPORT"
fi

if [ "$ERRORS" -eq 0 ]; then
    printf '\nУсі автоматичні перевірки пройдено.\n'
else
    printf '\nКількість невиконаних перевірок: %s\n' "$ERRORS"
    exit 1
fi
