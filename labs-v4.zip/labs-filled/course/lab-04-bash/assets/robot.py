#!/usr/bin/env python3

import os
import signal
import sys
import time


def finish(signum: int, _frame: object) -> None:
    print(
        f"robot: отримано сигнал {signal.Signals(signum).name}",
        flush=True,
    )
    print("robot: ресурси звільнено, роботу завершено", flush=True)
    raise SystemExit(0)


signal.signal(signal.SIGINT, finish)
signal.signal(signal.SIGTERM, finish)

environment = os.environ.get("ROBOT_ENV")
if not environment:
    print("robot: змінна ROBOT_ENV не встановлена", file=sys.stderr, flush=True)
    raise SystemExit(2)

print(
    f"robot: запуск, PID={os.getpid()}, середовище={environment}",
    flush=True,
)

iteration = 0
while True:
    iteration += 1
    print(f"robot: цикл {iteration}", flush=True)
    if iteration % 3 == 0:
        print(
            f"robot: діагностичний запис {iteration}",
            file=sys.stderr,
            flush=True,
        )
    time.sleep(1)
