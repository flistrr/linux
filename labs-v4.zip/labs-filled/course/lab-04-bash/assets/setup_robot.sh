#!/usr/bin/env bash

set -u

# TODO: перевірити кількість і значення аргументів.
MODE="${1:-}"

SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
RUNTIME_DIR="$SCRIPT_DIR/runtime/$MODE"
ROBOT_PID=''

prepare_directories() {
    # TODO: у циклі створити config, data і logs.
    :
}

stop_robot() {
    # TODO: коректно завершити дочірній процес і дочекатися його.
    :
}

# TODO: зареєструвати stop_robot для SIGTERM і SIGINT.
# TODO: експортувати ROBOT_ENV.
# TODO: викликати prepare_directories.
# TODO: створити config/robot.conf.
# TODO: запустити robot.py з окремими журналами stdout і stderr.
# TODO: зберегти PID дочірнього процесу до robot.pid.
# TODO: дочекатися дочірнього процесу.
