#!/usr/bin/env bash

set -u

SCRIPT_DIR=${LAB_DIR:-$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)}
REPORT="$SCRIPT_DIR/assets/firewall-report.txt"
LOG="$SCRIPT_DIR/assets/client.log"
PCAP="/root/handshake.pcap"
NODE="$(id -un)-node"
ERRORS=0

pass() { printf '  [OK] %s\n' "$1"; }
fail() { printf '  [ПОМИЛКА] %s\n' "$1"; ERRORS=$((ERRORS + 1)); }

node() { lxc exec "$NODE" -- "$@"; }

NODE_READY=0
if ! command -v lxc >/dev/null 2>&1; then
    fail "команда lxc недоступна; слід звернутися до викладача"
elif ! lxc list >/dev/null 2>&1; then
    fail "немає доступу до lxc: сеанс не має членства в групі lxd; слід вийти із сервера й увійти знову"
elif ! lxc info "$NODE" >/dev/null 2>&1; then
    fail "контейнер $NODE не знайдено; слід звернутися до викладача"
else
    STATUS=$(lxc info "$NODE" | awk '/^Status:/ { print $2 }')
    if [ "$STATUS" = "RUNNING" ]; then
        pass "контейнер $NODE запущено"
        NODE_READY=1
    else
        fail "контейнер $NODE не запущено (стан: ${STATUS:-невідомий})"
    fi
fi

if [ "$NODE_READY" -eq 1 ]; then
    ENABLED=$(node systemctl is-enabled robot-telemetry.service 2>/dev/null)
    ACTIVE=$(node systemctl is-active robot-telemetry.service 2>/dev/null)
    if [ "$ENABLED" = "enabled" ]; then
        fail "служба robot-telemetry досі ввімкнена для автоматичного запуску"
    elif [ "$ACTIVE" = "active" ]; then
        fail "служба robot-telemetry вимкнена, але досі працює"
    else
        pass "служба robot-telemetry вимкнена й не працює (${ENABLED:-не знайдено})"
    fi
    if node ss -Htln 2>/dev/null | awk '{ print $4 }' | grep -q ':9100$'; then
        fail "у контейнері досі прослуховується TCP-порт 9100"
    else
        pass "TCP-порт 9100 у контейнері не прослуховується"
    fi

    UFW_VERBOSE=$(node ufw status verbose 2>/dev/null)
    UFW_RULES=$(node ufw status 2>/dev/null)
    if printf '%s\n' "$UFW_VERBOSE" | grep -q '^Status: active'; then
        pass "firewall контейнера активний"
    else
        fail "firewall контейнера не активний"
    fi
    if printf '%s\n' "$UFW_VERBOSE" | grep -q '^Default:.*deny (incoming)'; then
        pass "політика вхідного трафіку — deny"
    else
        fail "політика вхідного трафіку не deny"
    fi
    if printf '%s\n' "$UFW_RULES" | grep -Eq '^(22(/tcp)?|OpenSSH) +ALLOW'; then
        pass "є правило ufw, що дозволяє SSH"
    else
        fail "немає правила ufw, що дозволяє SSH (порт 22/tcp)"
    fi

    if node test -f "$PCAP"; then
        SYN_COUNT=$(node tcpdump -n -r "$PCAP" 'tcp[tcpflags] & tcp-syn != 0 and tcp[tcpflags] & tcp-ack == 0 and dst port 5000' 2>/dev/null | grep -c .)
        if [ "${SYN_COUNT:-0}" -gt 0 ]; then
            pass "$PCAP містить пакет SYN до порту 5000"
        else
            fail "у $PCAP немає пакета SYN до порту 5000"
        fi
    else
        fail "у контейнері не знайдено $PCAP"
    fi
fi

if [ -f "$LOG" ]; then
    if grep -q '| OK MOVE 100$' "$LOG"; then
        pass "client.log містить відповідь OK MOVE 100"
    else
        fail "у client.log немає відповіді OK MOVE 100"
    fi
    if grep -q '| помилка: .*Connection refused' "$LOG"; then
        pass "client.log містить запис про відмову в з'єднанні"
    else
        fail "у client.log немає запису про відмову в з'єднанні (Connection refused)"
    fi
    if grep -q '| помилка: .*timed out' "$LOG"; then
        pass "client.log містить запис про вичерпання часу очікування"
    else
        fail "у client.log немає запису про вичерпання часу очікування (timed out)"
    fi
else
    fail "не знайдено $LOG"
fi

if [ -f "$REPORT" ]; then
    pass "файл firewall-report.txt існує"
    if grep -q '<заповнити>' "$REPORT"; then
        fail "у звіті залишилися поля <заповнити>"
    else
        pass "усі поля звіту заповнено"
    fi
else
    fail "не знайдено $REPORT"
fi

if [ "$ERRORS" -eq 0 ]; then
    printf '\nУсі автоматичні перевірки пройдено.\n'
else
    printf '\nКількість невиконаних перевірок: %s\n' "$ERRORS"
    exit 1
fi
