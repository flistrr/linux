#!/usr/bin/env bash
# Запуск сервера команд у фоновому режимі (практика 10).
# Сервер продовжує роботу після закриття вікна, а його вивід дописується
# до ~/robot_server.log.

DIR=$(cd "$(dirname "$0")" && pwd)

nohup python3 "$DIR/robot_server.py" 5000 --bind 127.0.0.1 >> "$HOME/robot_server.log" 2>&1 &

echo "Сервер команд запущено у фоновому режимі, PID $!"
echo "Вивід сервера: $HOME/robot_server.log"
