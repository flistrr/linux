#!/usr/bin/env bash

set -u

COURSE_DIR="${LINUX_COURSE_DIR:-${HOME}/labs}"
LAB_DIR="$COURSE_DIR/lab-06"
LOG_FILE="$LAB_DIR/status.log"

TIMESTAMP=$(date '+%Y-%m-%d %H:%M:%S')
UPTIME=$(uptime -p)
LOAD=$(cut -d ' ' -f 1-3 /proc/loadavg)
DISK=$(df -h "$HOME" | awk 'NR == 2 { print $5 " з " $2 }')

printf '%s | %s | load average: %s | диск: %s\n' \
    "$TIMESTAMP" "$UPTIME" "$LOAD" "$DISK" >> "$LOG_FILE"
