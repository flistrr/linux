#!/usr/bin/env python3
"""TCP-клієнт для надсилання команди роботу (практика 8).

Запуск: python3 robot_client.py <адреса> <порт> "<команда>" [--wait N]

Клієнт підключається до сервера, надсилає одну команду рядком, завершеним
'\\n', і виводить відповідь. З параметром --wait N з'єднання залишається
відкритим ще N секунд після відповіді. Кожен обмін або помилка дописується
рядком до файла client.log у каталозі програми.
"""

import argparse
import socket
import sys
import time
from datetime import datetime
from pathlib import Path

LOG_FILE = Path(__file__).resolve().parent / "client.log"
TIMEOUT = 5


def write_log(text):
    stamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with LOG_FILE.open("a", encoding="utf-8") as log:
        log.write(f"{stamp} | {text}\n")


def main():
    parser = argparse.ArgumentParser(description="TCP-клієнт команд робота")
    parser.add_argument("host", help="IP-адреса або ім'я сервера")
    parser.add_argument("port", type=int, help="TCP-порт сервера")
    parser.add_argument("command", help='команда, наприклад "MOVE 100"')
    parser.add_argument("--wait", type=float, default=0,
                        help="скільки секунд тримати з'єднання відкритим після відповіді")
    args = parser.parse_args()
    target = f"{args.host}:{args.port}"

    try:
        with socket.create_connection((args.host, args.port), timeout=TIMEOUT) as sock:
            local = sock.getsockname()
            remote = sock.getpeername()
            print(f"З'єднання: {local[0]}:{local[1]} -> {remote[0]}:{remote[1]}")

            sock.sendall((args.command + "\n").encode("utf-8"))
            print(f"Надіслано: {args.command}")

            reply = sock.makefile("r", encoding="utf-8", errors="replace").readline().strip()
            if not reply:
                reply = "(сервер закрив з'єднання без відповіді)"
            print(f"Відповідь: {reply}")
            write_log(f"{target} | {args.command} | {reply}")

            if args.wait > 0:
                print(f"З'єднання залишається відкритим {args.wait:g} с")
                time.sleep(args.wait)
    except OSError as exc:
        print(f"Помилка: {exc}", file=sys.stderr)
        write_log(f"{target} | {args.command} | помилка: {exc}")
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
