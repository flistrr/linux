#!/usr/bin/env python3
"""TCP-сервер команд робота для практики 8.

Прикладний протокол: одна команда — один рядок, завершений символом '\\n'.
TCP передає потік байтів без меж повідомлень, тому межу команди задає
сама програма. Підтримувані команди:

    MOVE <число>  ->  OK MOVE <число>
    STOP          ->  OK STOP
    інше          ->  ERROR unknown command

Запуск: python3 robot_server.py [порт]   (типово порт 5000)
Зупинка: Ctrl+C
"""

import argparse
import socket
import sys
import threading

BIND_ADDRESS = "0.0.0.0"


def process(command):
    """Повертає відповідь сервера на одну команду."""
    parts = command.split()
    if len(parts) == 2 and parts[0].upper() == "MOVE" and parts[1].lstrip("-").isdigit():
        return f"OK MOVE {parts[1]}"
    if len(parts) == 1 and parts[0].upper() == "STOP":
        return "OK STOP"
    return "ERROR unknown command"


def serve_client(conn, address):
    """Обслуговує одне прийняте з'єднання в окремому потоці виконання."""
    peer = f"{address[0]}:{address[1]}"
    print(f"Прийнято з'єднання від {peer}", flush=True)
    with conn, conn.makefile("r", encoding="utf-8", errors="replace", newline="\n") as reader:
        for line in reader:
            command = line.strip()
            if not command:
                continue
            reply = process(command)
            print(f"{peer}: команда «{command}», відповідь «{reply}»", flush=True)
            conn.sendall((reply + "\n").encode("utf-8"))
    print(f"З'єднання з {peer} закрито", flush=True)


def main():
    parser = argparse.ArgumentParser(description="TCP-сервер команд робота")
    parser.add_argument("port", nargs="?", type=int, default=5000, help="TCP-порт (типово 5000)")
    args = parser.parse_args()

    # Сокет очікування з'єднань: bind пов'язує його з адресою й портом,
    # listen переводить у стан LISTEN.
    listener = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    try:
        listener.bind((BIND_ADDRESS, args.port))
    except OSError as exc:
        print(f"Не вдалося зайняти порт {args.port}: {exc}", file=sys.stderr)
        return 1
    listener.listen()
    print(f"Сервер очікує з'єднань на {BIND_ADDRESS}:{args.port}; зупинка — Ctrl+C", flush=True)

    try:
        while True:
            # accept повертає окремий сокет для кожного прийнятого з'єднання;
            # сокет очікування продовжує приймати наступних клієнтів.
            conn, address = listener.accept()
            threading.Thread(target=serve_client, args=(conn, address), daemon=True).start()
    except KeyboardInterrupt:
        print("\nСервер зупинено", flush=True)
    finally:
        listener.close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
