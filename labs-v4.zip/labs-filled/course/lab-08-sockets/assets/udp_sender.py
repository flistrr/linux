#!/usr/bin/env python3
"""Надсилання однієї UDP-датаграми (практика 8).

Запуск: python3 udp_sender.py <адреса> <порт> "<текст>"

Програма надсилає текст однією датаграмою через сокет без заданої
віддаленої адреси (sendto) і виводить кількість надісланих байтів.
Відповіді вона не очікує.
"""

import argparse
import socket
import sys


def main():
    parser = argparse.ArgumentParser(description="Надсилання однієї UDP-датаграми")
    parser.add_argument("host", help="IP-адреса або ім'я отримувача")
    parser.add_argument("port", type=int, help="UDP-порт отримувача")
    parser.add_argument("text", help="текст датаграми")
    args = parser.parse_args()

    data = (args.text + "\n").encode("utf-8")
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
            sent = sock.sendto(data, (args.host, args.port))
    except OSError as exc:
        print(f"Помилка: {exc}", file=sys.stderr)
        return 1
    print(f"Надіслано {sent} байтів на {args.host}:{args.port}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
