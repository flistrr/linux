# Лаби 1–10 (Linux): локальний стенд, заповнені звіти, готові файли

**Покрокова інструкція «що запускати по порядку» — `START-HERE.txt`.** Нижче — те саме з поясненнями.

## Схема

- **Мак** — лише термінал: Terminal → `multipass shell linux-lab`.
- **VM `linux-lab`** = «сервер» курсу. Запрошення `ubuntu@linux-lab:~$`. Тут лежать `~/labs/…`, звіти, `check-lab.sh`.
- **Контейнер `ubuntu-node`** = «`<логін>-node`». Вхід з VM: `lxc exec ubuntu-node -- bash`
  (запрошення `root@ubuntu-node:~#`, вихід `exit`). Тут працюєш від root, без sudo.

Кілька вікон: на Маці новий таб Terminal (⌘T) → `multipass shell linux-lab`, або tmux у VM
(`tmux new -s labs`, нове вікно Ctrl+B c, перемикання Ctrl+B n).

Адреси — у кожному новому вікні VM:
```bash
NODE_IP=$(lxc list ubuntu-node -c 4 --format csv | cut -d' ' -f1)          # адреса контейнера
BR_IP=$(ip -4 -o addr show lxdbr0 | awk '{print $4}' | cut -d/ -f1)        # адреса «сервера» в lxdbr0
```
У контейнері адреса «сервера» = шлюз: `ip -4 route | awk '/default/ {print $3}'`.

Звіти редагуєш у VM: `nano <файл>`, зберегти Ctrl+O Enter, вийти Ctrl+X.
Позначки `⟦…⟧` = значення з твоєї машини, команда — всередині. Решту вже заповнено.

## Один раз: стенд і файли

```bash
# Мак
multipass transfer ~/Downloads/labs-v4.zip linux-lab:/home/ubuntu/
multipass shell linux-lab

# VM
python3 -m zipfile -e labs-v4.zip .
bash labs-filled/make-stand.sh     # можна запускати повторно; лог — ~/make-stand.log
exit                               # і знову: multipass shell linux-lab

ls /home/shared/labs               # 10 папок лаб
lxc list                           # ubuntu-node RUNNING з IPv4
bash labs-filled/deploy.sh         # матеріали + звіти → ~/labs/…; лагодить попередній невдалий запуск
```

## Де і як запускати кожну лабу

| Лаба | Де | Робоча папка | Що здається |
|---|---|---|---|
| 1 | VM | `~/labs/lab-01` | `report.txt` |
| 2 | VM | `~/labs/lab-02` | `workspace/` з `report.txt` |
| 3 | VM | `~/labs/lab-03/assets` | `process-report.txt`, `logs/` |
| 4 | VM | `~/labs/lab-04` | `setup_robot.sh`, `runtime/development` |
| 5 | VM | `~/labs/lab-05` | `~/.config/systemd/user/robot.service`, `service-report.txt` |
| 6 | VM | `~/labs/lab-06-journal` | `status.service`, `status.timer`, `status.log`, `journal-report.txt` |
| 7 | VM + контейнер | `~/labs/lab-07-network` | `assets/network-report.txt`, запис у `/etc/hosts` контейнера |
| 8 | VM + 2 вікна контейнера | `~/labs/lab-08-sockets` | `assets/sockets-report.txt`, `assets/client.log` |
| 9 | 2–3 вікна VM + контейнер | `~/labs/lab-09-ssh` | `assets/ssh-report.txt` + стан контейнера |
| 10 | VM + 2 вікна контейнера | `~/labs/lab-10-firewall` | `assets/firewall-report.txt`, `assets/client.log`, `/root/handshake.pcap` у контейнері |

### Лаба 1 — VM
```bash
cd ~/labs/lab-01 && bash lab01-fill.sh       # → ~/labs/lab-01/report.txt, усе заповнено
```

### Лаба 2 — VM
```bash
bash ~/labs/lab-02/lab02-run.sh              # → ~/labs/lab-02/workspace/ і workspace/report.txt
less ~/labs/lab-02/workspace/data/raw/application.log    # крок із less — руками, q = вихід
```
Якщо `workspace/` уже є з невдалої спроби: `mv ~/labs/lab-02/workspace ~/labs/lab-02/workspace.old`.

### Лаба 3 — VM, `~/labs/lab-03/assets`
```bash
cd ~/labs/lab-03/assets
python3 worker.py                 # Ctrl+Z → jobs -l → bg %1 → fg %1 → Ctrl+C → echo $?   (130)
python3 worker.py > /dev/null & echo $! > worker.pid
ps -o pid,ppid,stat,tty,cmd -p "$(cat worker.pid)"; pgrep -af "python3 worker.py"
kill -SIGSTOP "$(cat worker.pid)"; ps -o pid,stat -p "$(cat worker.pid)"     # T
kill -SIGCONT "$(cat worker.pid)"; kill "$(cat worker.pid)"
mkdir -p logs
python3 worker.py >> logs/worker.log 2>> logs/worker-error.log & echo $! > worker.pid
sleep 5; kill -SIGTERM "$(cat worker.pid)"; wait "$(cat worker.pid)"; echo $?   # 0
python3 worker.py >> logs/worker.log 2>> logs/worker-error.log & echo $! > worker.pid
sleep 3; kill -SIGKILL "$(cat worker.pid)"; wait "$(cat worker.pid)"; echo $?   # 137
nano process-report.txt           # вписати PID і PPID
```
`wait` працює лише в тому вікні, де процес запущено.

### Лаба 4 — VM, `~/labs/lab-04`
```bash
cd ~/labs/lab-04
# завдання 1 (export / source) — руками; що казати — labs-filled/lab-04-bash/NOTES.txt
./setup_robot.sh; echo $?                    # інструкція, код 1
./setup_robot.sh unknown; echo $?            # помилка, код 1
./setup_robot.sh development & SETUP_PID=$!
sleep 3; kill -TERM "$SETUP_PID"; wait "$SETUP_PID"; echo $?    # 0
tail -n 5 runtime/development/logs/robot.log
# додаткове: mkdir -p bin && ln -s ../setup_robot.sh bin/setup-robot && export PATH="$HOME/labs/lab-04/bin:$PATH"
```

### Лаба 5 — VM
```bash
systemd-analyze; systemd-analyze blame | head -n 5; systemd-analyze critical-chain
sudo dmesg | head -n 20; sudo dmesg | grep -i -m 5 -E 'virtio|vda|enp|eth'
systemctl status ssh; systemctl cat ssh

mkdir -p ~/.config/systemd/user
cp ~/labs-filled/lab-05-services/systemd-user/robot.service ~/.config/systemd/user/
nano ~/.config/systemd/user/robot.service    # для завдання 3 тимчасово прибери Restart= і RestartSec=, повернеш у 4.2
systemctl --user daemon-reload
systemctl --user start robot; systemctl --user status robot
# далі завдання 4 за методичкою: прибрати Environment → збій, код 2; Restart=… ; SIGKILL; stop
nano ~/labs/lab-05/service-report.txt
```
Службу `robot` після лаби не зупиняй — вона потрібна в лабі 6.

### Лаба 6 — VM
```bash
systemctl --user enable robot; ls -l ~/.config/systemd/user/default.target.wants/; systemctl --user disable robot
journalctl --user-unit robot -n 20; journalctl --user-unit robot -n 5 -o short-iso; journalctl --user-unit robot -f
journalctl --user-unit robot -n 8 -o json-pretty | grep -E '"(MESSAGE|PRIORITY)"'
journalctl --user-unit robot -p warning      # до і після SyslogLevel=warning у [Service] (+ daemon-reload, restart)
sudo journalctl -b -p err; sudo journalctl -u ssh -n 20; ls /var/log; sudo tail /var/log/auth.log

cp ~/labs-filled/lab-06-journal/systemd-user/status.service ~/labs-filled/lab-06-journal/systemd-user/status.timer ~/.config/systemd/user/
systemctl --user daemon-reload
systemctl --user start status.service; cat ~/labs/lab-06-journal/status.log
systemctl --user enable --now status.timer; systemctl --user list-timers
nano ~/labs/lab-06-journal/journal-report.txt
# через кілька хвилин (≥ 2 записи) — завдання 6, прибирання:
systemctl --user disable --now status.timer robot
```

### Лаба 7 — VM + контейнер
VM:
```bash
cd ~/labs/lab-07-network
ip -br link; ip -4 addr; ip -4 route | grep default      # зовнішній інтерфейс — той, що в default (зазвичай enp0s1)
ping -c 4 "$NODE_IP"; ip -4 neigh show dev lxdbr0
ip -4 route; ip route get 8.8.8.8; hostname
```
Контейнер (`lxc exec ubuntu-node -- bash`):
```bash
ip -br link; ip -4 addr show eth0; ip link show eth0
GW=$(ip -4 route | awk '/default/ {print $3}'); ping -c 4 "$GW"
ip -4 neigh; ip -4 route; ip route get 8.8.8.8; tracepath -n -m 10 8.8.8.8
hostname; getent hosts example.com; dig example.com; nslookup example.com
echo "$GW server" >> /etc/hosts; getent hosts server; dig server; ping -c 2 server
```
VM: `nano assets/network-report.txt`, потім `./check-lab.sh`.
Мережа тут Multipass (192.168.64.x, приватний діапазон 192.168.0.0/16), а не AWS — підказки з 172.31.x.x не підходять.

### Лаба 8 — VM + 2 вікна контейнера
```bash
# контейнер, один раз
cp /home/shared/labs/lab-08-sockets/assets/robot_server.py ~/
```
VM: `cd ~/labs/lab-08-sockets`. Нижче «К1»/«К2» — два вікна контейнера.
```bash
# порти сервера (VM)
sudo ss -tulnp
# TCP вручну
#   К1: nc -l 5000
nc "$NODE_IP" 5000                 # VM, набрати кілька рядків
#   К2: ss -tanp | grep 5000      VM: ss -tan | grep 5000
# HTTP
curl -v http://example.com/ -o /dev/null
#   К1: python3 -m http.server 8000
curl -v "http://$NODE_IP:8000/"; curl -v "http://$NODE_IP:8000/status"
# сервер робота
#   К1: python3 ~/robot_server.py
python3 assets/robot_client.py "$NODE_IP" 5000 "MOVE 100"
python3 assets/robot_client.py "$NODE_IP" 5000 "JUMP 5"
#   два клієнти: у двох вікнах VM
python3 assets/robot_client.py "$NODE_IP" 5000 "MOVE 100" --wait 30
#   К2: ss -tan | grep 5000
# UDP
#   К1: nc -u -l 5001             К2: ss -uan | grep 5001
nc -u "$NODE_IP" 5001              # VM, набрати кілька рядків
# без отримувача: у К1 усе зупинити (Ctrl+C), потім у VM
python3 assets/robot_client.py "$NODE_IP" 5000 "MOVE 100"
python3 assets/udp_sender.py "$NODE_IP" 5001 "hello"
```
Клієнт запускай саме з `~/labs/lab-08-sockets` як `assets/robot_client.py`: `client.log` пишеться поруч зі скриптом.
Потім `nano assets/sockets-report.txt`.

### Лаба 9 — 2–3 вікна VM + контейнер
Контейнер:
```bash
adduser admin1; usermod -aG sudo admin1; groups admin1
sshd -T | grep -E '^(permitrootlogin|passwordauthentication|pubkeyauthentication) '
ip -4 addr show eth0; ssh-keygen -lf /etc/ssh/ssh_host_ed25519_key.pub
```
VM:
```bash
cd ~/labs/lab-09-ssh
ssh admin1@"$NODE_IP"              # звір відбиток; раз неправильний пароль, потім правильний; exit
ssh-keygen -F "$NODE_IP"
[ -f ~/.ssh/id_ed25519 ] || ssh-keygen -t ed25519
ssh-copy-id admin1@"$NODE_IP"; ssh admin1@"$NODE_IP" hostname
#   контейнер: chmod g+w /home/admin1/.ssh/authorized_keys
ssh -v admin1@"$NODE_IP"           # ключ відхилено → пароль; контейнер: journalctl -u ssh -n 20
#   контейнер: chmod 600 /home/admin1/.ssh/authorized_keys
```
Тунель:
```bash
# контейнер, окреме вікно:
python3 -m http.server 8000 --bind 127.0.0.1 --directory /home/shared/labs/lab-09-ssh/assets/dashboard
# VM:
curl "http://$NODE_IP:8000/"                                           # відмова
ssh -N -L $((10000 + $(id -u))):127.0.0.1:8000 admin1@"$NODE_IP"       # друге вікно VM, лишити
curl "http://127.0.0.1:$((10000 + $(id -u)))/"; ss -tlnp | grep $((10000 + $(id -u)))   # третє вікно
```
ros2_ws (VM, `~/labs/lab-09-ssh`):
```bash
du -sh assets/ros2_ws
tar -czf ros2_ws.tar.gz --exclude=build --exclude=install --exclude=log -C assets ros2_ws
tar -tzf ros2_ws.tar.gz; ls -lh ros2_ws.tar.gz
scp ros2_ws.tar.gz admin1@"$NODE_IP": && ssh admin1@"$NODE_IP" 'tar -xzf ros2_ws.tar.gz'
nano assets/ros2_ws/src/robot_pkg/config/params.yaml
rsync -avz --dry-run --exclude=build --exclude=install --exclude=log assets/ros2_ws/ admin1@"$NODE_IP":ros2_ws/
rsync -avz           --exclude=build --exclude=install --exclude=log assets/ros2_ws/ admin1@"$NODE_IP":ros2_ws/
```
Захист SSH (контейнер; вікно `lxc exec` — резервний доступ, не закривай):
```bash
cp /etc/ssh/sshd_config /etc/ssh/sshd_config.bak
nano /etc/ssh/sshd_config                 # PermitRootLogin no, PasswordAuthentication no
sshd -t && systemctl reload ssh
sshd -T | grep -E '^(permitrootlogin|passwordauthentication) '   # passwordauthentication лишився yes
grep -ri passwordauthentication /etc/ssh/sshd_config.d/          # → 50-cloud-init.conf: виправити на no
sshd -t && systemctl reload ssh
# VM, нове вікно: ssh admin1@"$NODE_IP" (входить) і ssh -o PubkeyAuthentication=no admin1@"$NODE_IP" (Permission denied)
journalctl -u ssh --since today | grep -E 'Failed password|Connection closed'; lastb
```
VM: `nano assets/ssh-report.txt`, потім `./check-lab.sh`.

### Лаба 10 — VM + 2 вікна контейнера
Контейнер, вікно 1:
```bash
ss -tulpn; lsof -i -P -n
PID=$(ss -tlnp | awk '/:9100 / {match($0, /pid=[0-9]+/); print substr($0, RSTART+4, RLENGTH-4); exit}')
systemctl status "$PID"                      # перший рядок — unit (robot-telemetry.service)
systemctl disable --now robot-telemetry.service; ss -tlnp | grep 9100
ufw status verbose; ufw default deny incoming; ufw allow ssh; ufw status verbose; ufw enable
```
Контейнер, вікно 2: `python3 -m http.server 8000`.
VM (`cd ~/labs/lab-10-firewall`), у кожному стані: `nc -vz -w 3 "$NODE_IP" 22; nc -vz -w 3 "$NODE_IP" 8000`
(`-w 3`, інакше заблокований порт висить ~2 хв). Стани в контейнері: після `ufw enable` →
`ufw allow 8000/tcp` → `ufw delete allow 8000/tcp; ufw deny 8000/tcp` →
`iptables -S ufw-user-input; iptables -L ufw-user-input -n -v` → `ufw status numbered; ufw delete <N>`.

Клієнт не бачить сервер:
```bash
# контейнер:
bash /home/shared/labs/lab-10-firewall/assets/start-robot.sh
# VM (після кожного виправлення повторюй):
python3 assets/robot_client.py "$NODE_IP" 5000 "MOVE 100"
#   1) timed out  → контейнер: ufw status numbered; ufw allow 5000/tcp
#   2) refused    → контейнер: ss -tlnp | grep 5000 (127.0.0.1); pgrep -af robot_server; kill <PID>
#                   окреме вікно: python3 /home/shared/labs/lab-10-firewall/assets/robot_server.py 5000 --bind 0.0.0.0
#   3) OK MOVE 100 → Ctrl+C на сервері → клієнт (refused) → знову запустити сервер
```
Захоплення:
```bash
# контейнер, вікно 1:
tcpdump -i eth0 -n -w /root/handshake.pcap tcp port 5000
# VM: один раз клієнт; контейнер: Ctrl+C, потім
tcpdump -n -r /root/handshake.pcap
```
VM: `nano assets/firewall-report.txt`, потім `./check-lab.sh`. Firewall лиши ввімкненим з SSH і 5000/tcp.

## Наприкінці: зібрати й забрати

```bash
# VM
bash ~/labs-filled/collect.sh      # → ~/labs-submit.tar.gz; покаже, чого бракує і де лишились ⟦…⟧
# Мак
multipass transfer linux-lab:/home/ubuntu/labs-submit.tar.gz ~/Downloads/
```

Між сесіями: `multipass stop linux-lab` / `multipass start linux-lab` — усе зберігається.
Прибрати все: `multipass delete --purge linux-lab && brew uninstall --cask multipass`.

## Нюанси

- **Лаба 5, NRestarts:** з `RestartSec=2` п'ять запусків займають ~10 с — якраз межа ліміту
  `StartLimitBurst=5 / StartLimitIntervalSec=10s`. Якщо служба не падає в `failed`, а крутиться далі —
  це через цю межу; запиши NRestarts і що бачиш.
- **Лаба 9:** `PasswordAuthentication no` в основному `sshd_config` не діє, доки є
  `sshd_config.d/50-cloud-init.conf` з `yes`: sshd бере перше знайдене значення, а Include стоїть на початку.
- **Лаба 10:** check-lab вимагає в `client.log` і `timed out`, і `Connection refused` — вони з'являються
  природно в кроках 1 і 2 вище.
- **Локальний стенд ≠ курсовий:** `robot-telemetry` (лаба 10) і файл у `sshd_config.d` (лаба 9) підставив
  `make-stand.sh` за тим, що перевіряють check-lab.sh; на справжньому стенді назви можуть відрізнятись.
  Якщо викладач перевіряє стан на сервері курсу, лаби 5–10 доведеться повторити там (з `deploy.sh` це швидко).

## Що в архіві

| Файл | Призначення |
|---|---|
| `make-stand.sh` | стенд у VM: `/home/shared/labs`, LXD, `ubuntu-node`, ssh/ufw/tcpdump у ньому, `robot-telemetry` |
| `deploy.sh` | матеріали + заповнені звіти → `~/labs/…` за шляхами з методичок |
| `collect.sh` | збір усього для здачі в `~/labs-submit.tar.gz` + прогін `check-lab.sh` |
| `course/` | оригінальні матеріали лаб (з твого архіву, без змін) |
| `lab-01-system/lab01-fill.sh`, `lab-02-files/lab02-run.sh` | лаби 1 і 2 автоматично |
| `lab-04-bash/` | готовий `setup_robot.sh`, `set-env.sh`, `NOTES.txt` |
| `lab-05-services/systemd-user/`, `lab-06-journal/systemd-user/` | unit-файли |
| `lab-*/assets/*-report.txt` | заповнені звіти (з `⟦…⟧` для значень з машини) |
