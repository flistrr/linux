#!/usr/bin/env bash
# Локальна копія стенда курсу всередині VM Ubuntu 24.04 (Multipass):
#   - /home/shared/labs з матеріалами лаб (лише читання), назви каталогів як у методичках;
#   - LXD-контейнер <логін>-node з мостом lxdbr0 і тим самим /home/shared/labs усередині;
#   - у контейнері: openssh-server із дозволеним входом за паролем через sshd_config.d (лаба 9),
#     зайва служба robot-telemetry на 0.0.0.0:9100 (лаба 10), ufw вимкнено.
#
# Запуск у VM:   bash labs-filled/make-stand.sh
# Змінює лише цю VM. Повторний запуск безпечний (зроблене пропускається).

set -eu

SRC=$(CDPATH='' cd -- "$(dirname -- "$0")" && pwd)
ARCH="${1:-$SRC/course}"            # розпакований архів викладача (lab-01-system … lab-10-firewall)
ME=$(id -un)
NODE="$ME-node"
SHARED=/home/shared/labs
LXC=${LXC:-/snap/bin/lxc}
LXD=${LXD:-/snap/bin/lxd}

say() { printf '\n== %s\n' "$*"; }
LOG="$HOME/make-stand.log"
exec > >(tee -a "$LOG") 2>&1
trap 'echo; echo "!! make-stand.sh зупинився на рядку $LINENO. Повний вивід: $LOG"' ERR
node() { sudo "$LXC" exec "$NODE" -- "$@"; }

if [ ! -d "$ARCH/lab-07-network" ]; then
    echo "Не знайдено матеріалів лаб у $ARCH (очікую lab-01-system … lab-10-firewall)" >&2
    exit 1
fi

say "Спільний каталог $SHARED (лише читання для студента)"
sudo mkdir -p "$SHARED"
copy_lab() {
    if [ ! -d "$SHARED/$2" ]; then
        sudo cp -r "$ARCH/$1" "$SHARED/$2"
        echo "  $SHARED/$2"
    fi
}
copy_lab lab-01-system    lab-01
copy_lab lab-02-files     lab-02
copy_lab lab-03-processes lab-03
copy_lab lab-04-bash      lab-04
copy_lab lab-05-services  lab-05-services
copy_lab lab-06-journal   lab-06-journal
copy_lab lab-07-network   lab-07-network
copy_lab lab-08-sockets   lab-08-sockets
copy_lab lab-09-ssh       lab-09-ssh
copy_lab lab-10-firewall  lab-10-firewall
sudo find "$SHARED" -name '*.sh' -exec chmod +x {} +
sudo chown -R root:root /home/shared
sudo chmod -R a+rX,go-w /home/shared

say "Пакети у VM"
# Свіжа Ubuntu одразу після старту оновлюється сама й тримає apt — чекаємо до 10 хв.
sudo cloud-init status --wait >/dev/null 2>&1 || true
APT="sudo env DEBIAN_FRONTEND=noninteractive apt-get -o DPkg::Lock::Timeout=600 -y -qq"
APT_OK=0
for try in 1 2 3; do
    if $APT update && $APT install unzip tmux file rsync curl lsof tcpdump netcat-openbsd \
            bind9-dnsutils iputils-tracepath rsyslog >/dev/null; then
        APT_OK=1; break
    fi
    echo "  apt зайнятий або впав (спроба $try/3), чекаю 30 с…"; sleep 30
done
# Користувацькі служби (robot, status.timer) працюють і після виходу із сеансу, як на сервері.
sudo loginctl enable-linger "$ME"

say "LXD"
if ! snap list lxd >/dev/null 2>&1; then
    sudo snap install lxd
fi
sudo "$LXD" waitready
if ! sudo "$LXC" network show lxdbr0 >/dev/null 2>&1; then
    sudo "$LXD" init --auto
fi
if ! id -nG "$ME" | tr ' ' '\n' | grep -qx lxd; then
    sudo usermod -aG lxd "$ME"
    RELOGIN=1
fi

say "Контейнер $NODE"
if ! sudo "$LXC" info "$NODE" >/dev/null 2>&1; then
    sudo "$LXC" launch ubuntu:24.04 "$NODE"
fi
printf '  чекаю на мережу'
for _ in $(seq 90); do
    if node ip -4 -o addr show dev eth0 2>/dev/null | grep -q inet; then break; fi
    printf '.'; sleep 2
done
echo
node cloud-init status --wait >/dev/null 2>&1 || true

if ! sudo "$LXC" config device show "$NODE" | grep -q '^shared:'; then
    sudo "$LXC" config device add "$NODE" shared disk source="$SHARED" path="$SHARED" readonly=true
fi

say "Налаштування всередині контейнера"
sudo "$LXC" exec "$NODE" -- bash -s <<'IN_NODE'
set -eu
export DEBIAN_FRONTEND=noninteractive
cloud-init status --wait >/dev/null 2>&1 || true
apt-get -o DPkg::Lock::Timeout=600 update -qq
apt-get -o DPkg::Lock::Timeout=600 install -y -qq openssh-server ufw tcpdump lsof netcat-openbsd bind9-dnsutils \
    iputils-ping iputils-tracepath curl rsync python3 >/dev/null

# Лаба 9: вхід за паролем дозволено ОКРЕМИМ файлом у sshd_config.d —
# саме він потім «перебиває» PasswordAuthentication no в основному sshd_config.
printf 'PasswordAuthentication yes\n' > /etc/ssh/sshd_config.d/50-cloud-init.conf
systemctl enable ssh >/dev/null 2>&1 || true
systemctl restart ssh

# Лаба 10: зайва служба, доступна з мережі.
mkdir -p /var/lib/robot-telemetry
printf 'battery=87\nstate=idle\n' > /var/lib/robot-telemetry/metrics.txt
cat > /etc/systemd/system/robot-telemetry.service <<'UNIT'
[Unit]
Description=Robot telemetry exporter (training service for lab 10)
After=network-online.target

[Service]
ExecStart=/usr/bin/python3 -m http.server 9100 --bind 0.0.0.0 --directory /var/lib/robot-telemetry
Restart=on-failure

[Install]
WantedBy=multi-user.target
UNIT
systemctl daemon-reload
systemctl enable --now robot-telemetry.service >/dev/null 2>&1

# Лаба 10 починається з вимкненого firewall.
ufw --force disable >/dev/null 2>&1 || true
IN_NODE

say "Перевірка стенда"
echo "  VM (сервер): $(hostname), lxdbr0 = $(ip -4 -o addr show dev lxdbr0 | awk '{print $4}')"
echo "  контейнер:   $(sudo "$LXC" list "$NODE" -c n4 --format csv)"
echo "  сокети в контейнері:"
node ss -tlnp | awk 'NR == 1 || /:22 |:9100 /' | sed 's/^/    /'
echo "  sshd у контейнері: $(node sshd -T | grep -E '^(permitrootlogin|passwordauthentication) ' | tr '\n' ' ')"
echo "  /home/shared/labs у контейнері: $(node ls /home/shared/labs | tr '\n' ' ')"

echo
if [ "${RELOGIN:-0}" = 1 ]; then
    echo "Стенд готовий. ВИЙДИ й ЗАЙДИ ЗНОВУ (exit, потім multipass shell …), щоб lxc працював без sudo."
else
    echo "Стенд готовий."
fi
if [ "$APT_OK" != 1 ]; then
    echo "УВАГА: пакети у VM не встановились (apt був зайнятий). Пізніше запусти make-stand.sh ще раз."
fi
echo "Далі: bash $SRC/deploy.sh"
