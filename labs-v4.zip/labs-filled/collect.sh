#!/usr/bin/env bash
# Збирає результати всіх лаб у ~/labs-submit/ і пакує в ~/labs-submit.tar.gz.
#
#   bash ~/labs-filled/collect.sh
#
# Нічого не змінює ні в ~/labs, ні в контейнері: лише копіює файли й запускає check-lab.sh
# (вони тільки читають стан). Наприкінці показує, яких файлів бракує й де лишилися ⟦…⟧.

set -u

LABS="$HOME/labs"
OUT="$HOME/labs-submit"
UNITS="$HOME/.config/systemd/user"
NODE="$(id -un)-node"
MISSING=0

rm -rf "$OUT" && mkdir -p "$OUT"

ld() {
    local d
    for d in "$LABS"/lab-"$1"*; do
        if [ -d "$d" ] && [ ! -L "$d" ]; then echo "$d"; return; fi
    done
    echo "$LABS/lab-$1-missing"
}

miss() { echo "  [нема] $1: $2"; MISSING=$((MISSING + 1)); }

# file <підкаталог> <шлях> — файл (через посилання — його вміст)
file() {
    if [ -e "$2" ]; then mkdir -p "$OUT/$1" && cp -L --preserve=mode,timestamps "$2" "$OUT/$1/"
    else miss "$1" "${2/#$HOME/\~}"; fi
}
# tree <підкаталог> <каталог> — каталог як є (посилання всередині лишаються посиланнями)
tree() {
    if [ -d "$2" ]; then mkdir -p "$OUT/$1" && cp -a "$2" "$OUT/$1/"
    else miss "$1" "${2/#$HOME/\~}/"; fi
}
# check <підкаталог> <каталог лаби> — вивід самоперевірки
check() {
    local s
    for s in "$2/check-lab.sh" "$HOME/linux-course/$(basename -- "$2")/check-lab.sh"; do
        if [ -f "$s" ]; then
            mkdir -p "$OUT/$1"
            (cd "$(dirname -- "$s")" && timeout 120 bash ./check-lab.sh) > "$OUT/$1/check-lab.txt" 2>&1
            echo "  check-lab $1: $(tail -n 1 "$OUT/$1/check-lab.txt")"
            return
        fi
    done
}
have_node() { command -v lxc >/dev/null 2>&1 && lxc info "$NODE" >/dev/null 2>&1; }

echo "Збираю файли:"
L=$(ld 01); file 01 "$L/report.txt"
L=$(ld 02); tree 02 "$L/workspace"
L=$(ld 03); file 03 "$L/assets/process-report.txt"
            file 03/logs "$L/assets/logs/worker.log"; file 03/logs "$L/assets/logs/worker-error.log"; check 03 "$L"
L=$(ld 04); file 04 "$L/setup_robot.sh"; tree 04/runtime "$L/runtime/development"
L=$(ld 05); file 05 "$UNITS/robot.service"; file 05 "$L/service-report.txt"; check 05 "$L"
L=$(ld 06); file 06 "$UNITS/status.service"; file 06 "$UNITS/status.timer"
            file 06 "$L/status.log"; file 06 "$L/journal-report.txt"; check 06 "$L"
L=$(ld 07); file 07 "$L/assets/network-report.txt"; check 07 "$L"
            if have_node; then mkdir -p "$OUT/07" && lxc exec "$NODE" -- cat /etc/hosts > "$OUT/07/container-etc-hosts.txt" 2>&1
            else miss 07 "/etc/hosts контейнера (lxc або $NODE недоступні)"; fi
L=$(ld 08); file 08 "$L/assets/sockets-report.txt"; file 08 "$L/assets/client.log"; check 08 "$L"
L=$(ld 09); file 09 "$L/assets/ssh-report.txt"; check 09 "$L"
L=$(ld 10); file 10 "$L/assets/firewall-report.txt"; file 10 "$L/assets/client.log"; check 10 "$L"
            if have_node && mkdir -p "$OUT/10" && lxc file pull "$NODE/root/handshake.pcap" "$OUT/10/" 2>/dev/null; then :
            else miss 10 "/root/handshake.pcap з контейнера"; fi

echo
UNFILLED=$(grep -rln -e '⟦' -e '<заповнити>' "$OUT" --include='*.txt' 2>/dev/null | grep -v '/check-lab.txt$' | sort)
if [ -n "$UNFILLED" ]; then
    echo "Ще не заповнено (⟦…⟧ або <заповнити>):"
    for f in $UNFILLED; do printf '  %s — %s шт.\n' "${f#"$OUT"/}" "$(grep -c -e '⟦' -e '<заповнити>' "$f")"; done
else
    echo "Незаповнених полів не знайдено."
fi
echo "Відсутніх файлів: $MISSING"

tar -czf "$HOME/labs-submit.tar.gz" -C "$HOME" labs-submit
echo
echo "Архів: ~/labs-submit.tar.gz ($(du -h "$HOME/labs-submit.tar.gz" | cut -f1))"
echo "Забрати на Мак (у Terminal Мака):"
echo "  multipass transfer linux-lab:$HOME/labs-submit.tar.gz ~/Downloads/"
