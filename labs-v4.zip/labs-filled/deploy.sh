#!/usr/bin/env bash
# Розкладає матеріали й заповнені файли по ~/labs/… — за шляхами з методичок і check-lab.sh.
#
#   bash ~/labs-filled/deploy.sh
#
# - Матеріали лаби беруться з /home/shared/labs (якщо є), інакше з копії в labs-filled/course/.
#   Відсутні файли докопіюються; наявні не перезаписуються.
# - Звіт, який ти вже почав заповнювати, НЕ перезаписується: скрипт лишає твою версію.
#   Порожній шаблон зберігається як *.orig, а на його місці з'являється посилання на заповнений звіт.
# - Робить симлінки ~/labs/lab-05 і ~/labs/lab-06 та виконуваний collect-status.sh.
# - Unit-файли systemd не встановлює — це кроки лаб 5–6.
# Змінює лише ~/labs. Повторний запуск безпечний і лагодить попередній невдалий запуск.

set -u

SRC=$(CDPATH='' cd -- "$(dirname -- "$0")" && pwd)
LABS="$HOME/labs"
SHARED=/home/shared/labs
COURSE="$SRC/course"
mkdir -p "$LABS"

note() { printf '%s\n' "$*" >&2; }
is_template() { grep -q -e '<заповнити>' -e 'TODO' "$1" 2>/dev/null; }

# Докопіювати з $1 у $2 файли, яких там ще немає (наявні не чіпаються).
fill_missing() {
    local from=$1 to=$2 f n=0
    while IFS= read -r f; do
        if [ ! -e "$to/$f" ] && [ ! -L "$to/$f" ]; then
            mkdir -p "$(dirname -- "$to/$f")" && cp -p "$from/$f" "$to/$f" && n=$((n + 1))
        fi
    done < <(cd "$from" && find . -type f | sed 's|^\./||')
    [ "$n" -gt 0 ] && note "  + $n файл(ів) матеріалів: ${from} → ${to/#$HOME/\~}"
    return 0
}

# Каталог лаби NN: наявний ~/labs/lab-NN* або новий з назвою за методичкою; матеріали докопіюються.
labdir() {
    local nn=$1 default=$2 d dir="" from=""
    for d in "$LABS"/lab-"$nn"*; do
        if [ -d "$d" ] && [ ! -L "$d" ]; then dir=$d; break; fi
    done
    for d in "$SHARED"/lab-"$nn"* "$COURSE"/lab-"$nn"*; do
        if [ -d "$d" ]; then from=$d; break; fi
    done
    [ -n "$dir" ] || dir="$LABS/$default"
    mkdir -p "$dir"
    if [ -n "$from" ]; then fill_missing "$from" "$dir"; else note "  ! матеріалів лаби $nn не знайдено"; fi
    echo "$dir"
}

show() { printf '  %-28s %s\n' "$1" "$2"; }

# Свій скрипт: завжди свіжа версія.
put_script() {
    local rel=$1 to=$2
    mkdir -p "$(dirname -- "$to")"
    if [ -f "$to" ] && ! cmp -s "$SRC/$rel" "$to" && [ ! -e "$to.orig" ]; then cp -p "$to" "$to.orig"; fi
    cp "$SRC/$rel" "$to" && chmod +x "$to"
    show "$(basename -- "$to")" "${to/#$HOME/\~}"
}

# Звіт / заповнюваний файл: зберегти вже розпочату роботу, шаблони → *.orig + посилання.
put_fill() {
    local rel=$1 to=$2 dir name f keep=""
    dir=$3
    name=$(basename -- "$to")
    mkdir -p "$(dirname -- "$to")"
    # 1) уже заповнена версія в каталозі лаби (твоя або з попереднього deploy) — лишаємо її
    if [ -f "$to" ] && [ ! -L "$to" ] && ! is_template "$to"; then
        keep=$to
    else
        while IFS= read -r f; do
            if ! is_template "$f"; then keep=$f; break; fi
        done < <(find "$dir" -maxdepth 3 -type f -name "$name" ! -name '*.orig' 2>/dev/null)
    fi
    if [ -z "$keep" ]; then
        if [ -f "$to" ] && [ ! -L "$to" ] && [ ! -e "$to.orig" ]; then mv "$to" "$to.orig"; fi
        rm -f "$to"
        cp "$SRC/$rel" "$to"
        keep=$to
    elif [ "$keep" != "$to" ]; then
        if [ -f "$to" ] && [ ! -L "$to" ] && [ ! -e "$to.orig" ]; then mv "$to" "$to.orig"; fi
        rm -f "$to"
        ln -s "$keep" "$to"
        show "$name" "${to/#$HOME/\~} → ${keep/#$HOME/\~} (твоя версія)"
    fi
    # 2) решта порожніх шаблонів з такою назвою → *.orig + посилання на робочий файл
    while IFS= read -r f; do
        [ "$f" = "$keep" ] && continue
        is_template "$f" || continue
        [ -e "$f.orig" ] || mv "$f" "$f.orig"
        rm -f "$f"
        ln -s "$keep" "$f"
    done < <(find "$dir" -maxdepth 3 -type f -name "$name" ! -name '*.orig' 2>/dev/null)
    case "$name" in *.sh) chmod +x "$keep" ;; esac
    [ "$keep" = "$to" ] && show "$name" "${to/#$HOME/\~}"
    return 0
}

echo "Матеріали й файли:"
L1=$(labdir 01 lab-01);           put_script lab-01-system/lab01-fill.sh "$L1/lab01-fill.sh"
L2=$(labdir 02 lab-02);           put_script lab-02-files/lab02-run.sh  "$L2/lab02-run.sh"
L3=$(labdir 03 lab-03);           put_fill lab-03-processes/assets/process-report.txt "$L3/assets/process-report.txt" "$L3"
L4=$(labdir 04 lab-04)
for f in robot.py; do              # setup_robot.sh за методичкою лежить у ~/labs/lab-04/, robot.py — поруч
    [ -e "$L4/$f" ] || { [ -f "$L4/assets/$f" ] && cp -p "$L4/assets/$f" "$L4/$f"; }
done
                                  put_fill lab-04-bash/assets/setup_robot.sh "$L4/setup_robot.sh" "$L4"
                                  put_script lab-04-bash/assets/set-env.sh "$L4/set-env.sh"
L5=$(labdir 05 lab-05-services);  put_fill lab-05-services/assets/service-report.txt "$L5/service-report.txt" "$L5"
L6=$(labdir 06 lab-06-journal);   put_fill lab-06-journal/assets/journal-report.txt "$L6/journal-report.txt" "$L6"
L7=$(labdir 07 lab-07-network);   put_fill lab-07-network/assets/network-report.txt "$L7/assets/network-report.txt" "$L7"
L8=$(labdir 08 lab-08-sockets);   put_fill lab-08-sockets/assets/sockets-report.txt "$L8/assets/sockets-report.txt" "$L8"
L9=$(labdir 09 lab-09-ssh);       put_fill lab-09-ssh/assets/ssh-report.txt "$L9/assets/ssh-report.txt" "$L9"
L10=$(labdir 10 lab-10-firewall); put_fill lab-10-firewall/assets/firewall-report.txt "$L10/assets/firewall-report.txt" "$L10"

echo "Шляхи з методичок:"
for pair in "lab-05:$L5" "lab-06:$L6"; do
    link=${pair%%:*}; target=$(basename -- "${pair#*:}")
    if [ "$target" != "$link" ] && [ ! -e "$LABS/$link" ]; then ln -s "$target" "$LABS/$link"; fi
    [ -L "$LABS/$link" ] && show "~/labs/$link" "→ $(readlink "$LABS/$link")"
done
if [ ! -f "$L6/collect-status.sh" ] && [ -f "$L6/assets/collect-status.sh" ]; then
    cp -p "$L6/assets/collect-status.sh" "$L6/collect-status.sh"
fi
if [ -f "$L6/collect-status.sh" ]; then chmod +x "$L6/collect-status.sh"; show "collect-status.sh" "${L6/#$HOME/\~}/ (виконуваний)"; fi

cat <<EOF

Готово. Порядок роботи — у ~/labs-filled/README.md (розділ «Де і як запускати кожну лабу»).
Не повторюй cp -r з методичок: матеріали вже на місці, а cp -r перезапише звіти шаблонами.
EOF
