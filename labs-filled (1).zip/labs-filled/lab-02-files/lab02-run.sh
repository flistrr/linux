#!/usr/bin/env bash
# Практика 2: виконує всі завдання й пише workspace/report.txt
# з командами та їхнім реальним виводом на ЦІЙ машині.
#
# Запуск (з каталогу роботи, де лежить assets/):
#   cd ~/labs/lab-02 && bash lab02-run.sh
#
# Скрипт нічого не змінює в assets/ і відмовляється працювати,
# якщо workspace/ уже існує (щоб не затерти ручну спробу).

set -u

LAB_DIR=$(pwd)
REPORT="workspace/report.txt"

if [ ! -d assets ] && [ -d /home/shared/labs/lab-02/assets ]; then
    # Підготовка з методички: копія разом із прихованими файлами.
    cp -r /home/shared/labs/lab-02/assets ./assets
fi
if [ ! -f assets/application.log ]; then
    echo "Немає assets/application.log у $LAB_DIR — запусти скрипт з ~/labs/lab-02" >&2
    exit 1
fi
if [ -e workspace ]; then
    echo "workspace/ уже існує. Перейменуй або видали її й запусти знову." >&2
    exit 1
fi

# Записати команду й її вивід (stdout+stderr) у звіт.
rec() {
    printf '$ %s\n' "$1" >> "$REPORT"
    eval "$1" >> "$REPORT" 2>&1
    printf '\n' >> "$REPORT"
}
say() { printf '%s\n' "$@" >> "$REPORT"; }

mkdir workspace
: > "$REPORT"
say "# Практика 2. Файли, права, посилання та потоки" \
    "Користувач: $(id -un), хост: $(hostname), дата: $(date '+%Y-%m-%d %H:%M')" \
    "Робочий каталог: $LAB_DIR" ""

say "## Завдання 1. Каталоги та файли" ""
say '$ mkdir workspace' ""
rec 'mkdir -p workspace/config workspace/data/raw workspace/data/processed workspace/logs workspace/scripts'
rec 'cp assets/settings.conf workspace/config/app.conf'
rec 'cp assets/application.log workspace/data/raw/application.log'
rec 'cp assets/backup.sh workspace/scripts/backup.sh'
say "Справжній тип archive.jpg (за вмістом, а не за розширенням):"
rec 'file assets/archive.jpg'
say "Пошук прихованого файла в assets (ім'я починається з крапки):"
rec 'ls -la assets'
rec 'find assets -maxdepth 1 -type f -name ".*"'
rec 'cat assets/.environment'

say "## Завдання 2. Перегляд і пошук" ""
rec 'head -n 3 workspace/data/raw/application.log'
rec 'tail -n 3 workspace/data/raw/application.log'
say '$ less workspace/data/raw/application.log' \
    "Журнал переглянуто посторінково (стрілки/пробіл), вихід — клавіша q." ""
rec 'grep ERROR workspace/data/raw/application.log'
rec 'grep -i database workspace/data/raw/application.log'
rec 'grep ERROR workspace/data/raw/application.log > workspace/data/processed/error-lines.txt'
rec 'grep ERROR workspace/data/raw/application.log | wc -l > workspace/data/processed/error-count.txt'
rec 'cat workspace/data/processed/error-count.txt'

say "## Завдання 3. Права доступу" ""
say "backup.sh — символьний формат (rwxr-x---), app.conf — числовий (640 = rw-r-----):"
rec 'chmod u=rwx,g=rx,o= workspace/scripts/backup.sh'
rec 'chmod 640 workspace/config/app.conf'
rec 'ls -l workspace/scripts/backup.sh workspace/config/app.conf'
rec 'stat workspace/scripts/backup.sh workspace/config/app.conf'
say "Перевірка права виконання:"
rec './workspace/scripts/backup.sh'

say "## Завдання 4. Посилання та inode" ""
say "Символічне посилання з відносною ціллю (ціль рахується від каталогу workspace):"
rec 'ln -s config/app.conf workspace/current-config'
rec 'ln workspace/data/raw/application.log workspace/data/raw/application-hard.log'
say "Порівняння 1 — файл і його жорстке посилання:"
rec 'ls -li workspace/data/raw/application.log workspace/data/raw/application-hard.log'
say "Порівняння 2 — символічне посилання (без -L) і його ціль:"
rec 'ls -li workspace/current-config workspace/config/app.conf'
say "Пояснення:" \
"- application.log і application-hard.log мають однаковий inode, бо жорстке посилання —" \
"  це ще одне ім'я в каталозі для того самого inode (тих самих даних і метаданих)." \
"  Окремої копії немає: зміна вмісту через одне ім'я видна через інше." \
"- current-config і config/app.conf мають різні inode, бо символічне посилання —" \
"  окремий маленький файл типу l, вміст якого — рядок шляху config/app.conf." \
"  ls -li без -L показує inode самого посилання, а не цілі." \
"- Лічильник жорстких посилань (число після прав у ls -l) — скільки імен вказує" \
"  на inode. Після ln він став 2 для обох імен. Дані звільняються лише тоді," \
"  коли лічильник падає до 0 (і файл ніхто не тримає відкритим). Символічне" \
"  посилання лічильник цілі не змінює; якщо ціль видалити, воно стане «битим»." ""

say "## Завдання 5. Потік помилок" ""
say "stderr спрямовано у файл, тому в терміналі повідомлення немає:"
rec 'ls workspace/missing.file 2> workspace/logs/command-errors.log'
rec 'ls workspace/missing.file 2>> workspace/logs/command-errors.log'
rec 'cat workspace/logs/command-errors.log'

say "## Контрольна точка" ""
rec 'ls -l workspace/config/app.conf workspace/scripts/backup.sh'
rec 'ls -li workspace/data/raw/application*'
rec 'ls -l workspace/current-config'
rec 'cat workspace/data/processed/error-count.txt'
rec 'wc -l workspace/logs/command-errors.log'

say "## Додаткове завдання" ""
say "Один конвеєр: лише WARNING і ERROR, з них — останні три рядки (оригінал не змінюється):"
rec "grep -E 'WARNING|ERROR' workspace/data/raw/application.log | tail -n 3"

echo "Готово. Звіт: $LAB_DIR/$REPORT"
echo "Структура:"
find workspace | sort
