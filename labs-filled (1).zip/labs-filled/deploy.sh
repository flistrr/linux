#!/usr/bin/env bash
# Розкладає заповнені файли з цього архіву по ~/labs/… на сервері курсу.
#
#   unzip labs-filled.zip && bash labs-filled/deploy.sh
#
# - Каталог лаби береться той, що вже є в ~/labs (lab-05-services тощо). Якщо його ще немає,
#   скрипт робить підготовку з методички: cp -r /home/shared/labs/lab-NN… ~/labs/
# - Шаблон звіту замінюється заповненим; якщо на місці лежала інша версія — вона лишається як *.orig.
# - Робить симлінки lab-05 і lab-06 та виконуваний collect-status.sh (косяки методичок, див. README).
# - Unit-файли systemd НЕ встановлює — це крок самих лаб 5–6.
# Змінює лише ~/labs. Повторний запуск безпечний.

set -u

SRC=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
LABS="$HOME/labs"
SHARED=/home/shared/labs
LAST=''
mkdir -p "$LABS"

# Каталог лаби NN: наявний у ~/labs → копія зі спільного каталогу → новий з назвою за методичкою.
labdir() {
    local nn=$1 default=$2 d
    for d in "$LABS"/lab-"$nn"*; do
        if [ -d "$d" ] && [ ! -L "$d" ]; then echo "$d"; return; fi
    done
    for d in "$SHARED"/lab-"$nn"*; do
        if [ -d "$d" ]; then
            cp -r "$d" "$LABS/" && echo "$LABS/$(basename -- "$d")"
            return
        fi
    done
    mkdir -p "$LABS/$default" && echo "$LABS/$default"
}

# put <файл з архіву> <каталог лаби> <типовий шлях усередині>
put() {
    local rel=$1 dir=$2 def=$3 name to
    name=$(basename -- "$rel")
    to=$(find "$dir" -maxdepth 3 -type f -name "$name" 2>/dev/null | head -n 1)
    [ -n "$to" ] || to="$dir/$def"
    mkdir -p "$(dirname -- "$to")"
    if [ -e "$to" ] && ! cmp -s "$SRC/$rel" "$to"; then
        [ -e "$to.orig" ] || cp -p "$to" "$to.orig"
    fi
    cp "$SRC/$rel" "$to"
    LAST=$to
    case "$name" in *.sh) chmod +x "$to" ;; esac
    printf '  %-44s → %s\n' "$rel" "${to/#$HOME/\~}"
}

echo "Розкладаю файли:"
L=$(labdir 01 lab-01);           put lab-01-system/lab01-fill.sh               "$L" lab01-fill.sh
L=$(labdir 02 lab-02);           put lab-02-files/lab02-run.sh                 "$L" lab02-run.sh
L=$(labdir 03 lab-03);           put lab-03-processes/assets/process-report.txt "$L" assets/process-report.txt
L=$(labdir 04 lab-04);           put lab-04-bash/assets/setup_robot.sh         "$L" setup_robot.sh
                                 put lab-04-bash/assets/set-env.sh             "$(dirname -- "$LAST")" set-env.sh
L=$(labdir 05 lab-05-services);  put lab-05-services/assets/service-report.txt "$L" service-report.txt
L5=$L
L=$(labdir 06 lab-06-journal);   put lab-06-journal/assets/journal-report.txt  "$L" journal-report.txt
L6=$L
L=$(labdir 07 lab-07-network);   put lab-07-network/assets/network-report.txt  "$L" assets/network-report.txt
L=$(labdir 08 lab-08-sockets);   put lab-08-sockets/assets/sockets-report.txt  "$L" assets/sockets-report.txt
L=$(labdir 09 lab-09-ssh);       put lab-09-ssh/assets/ssh-report.txt          "$L" assets/ssh-report.txt
L=$(labdir 10 lab-10-firewall);  put lab-10-firewall/assets/firewall-report.txt "$L" assets/firewall-report.txt

echo "Виправляю шляхи з методичок:"
if [ "$(basename -- "$L5")" != lab-05 ] && [ ! -e "$LABS/lab-05" ]; then
    ln -s "$(basename -- "$L5")" "$LABS/lab-05" && echo "  ~/labs/lab-05 → $(basename -- "$L5")"
fi
if [ "$(basename -- "$L6")" != lab-06 ] && [ ! -e "$LABS/lab-06" ]; then
    ln -s "$(basename -- "$L6")" "$LABS/lab-06" && echo "  ~/labs/lab-06 → $(basename -- "$L6")"
fi
if [ ! -f "$L6/collect-status.sh" ]; then
    for c in "$L6/assets/collect-status.sh" "$SHARED/lab-06-journal/collect-status.sh" "$SHARED/lab-06-journal/assets/collect-status.sh"; do
        if [ -f "$c" ]; then cp "$c" "$L6/collect-status.sh"; echo "  collect-status.sh → ${L6/#$HOME/\~}/"; break; fi
    done
fi
[ -f "$L6/collect-status.sh" ] && chmod +x "$L6/collect-status.sh" && echo "  chmod +x collect-status.sh"

cat <<EOF

Готово. Далі:
  - лаба 1: cd ~/labs/lab-01 && bash lab01-fill.sh
  - лаба 2: cd ~/labs/lab-02 && bash lab02-run.sh
  - решта: проходиш кроки з методички, у звітах замінюєш ⟦…⟧ своїми значеннями (nano)
  - unit-файли для лаб 5–6: $SRC/lab-05-services/systemd-user/ і lab-06-journal/systemd-user/
  - НЕ повторюй cp -r з методичок після цього скрипта: він перезапише заповнені звіти шаблонами
  - наприкінці: bash $SRC/collect.sh
EOF
