#!/usr/bin/env bash

set -u

usage() {
    echo "Використання: $(basename -- "$0") development|production" >&2
}

# Перевірка аргументів: рівно один, лише development або production.
if [ "$#" -ne 1 ]; then
    echo "Помилка: потрібен рівно один аргумент (отримано: $#)" >&2
    usage
    exit 1
fi

MODE="$1"

if [ "$MODE" != "development" ] && [ "$MODE" != "production" ]; then
    echo "Помилка: невідомий режим «$MODE»" >&2
    usage
    exit 1
fi

# Каталог самого скрипту. readlink -f розкриває символічне посилання,
# тому запуск через ~/labs/lab-04/bin/setup-robot теж бере шляхи від цього каталогу.
SCRIPT_PATH=$(readlink -f -- "$0" 2>/dev/null || printf '%s' "$0")
SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$SCRIPT_PATH")" && pwd)
RUNTIME_DIR="$SCRIPT_DIR/runtime/$MODE"
ROBOT_PID=''

prepare_directories() {
    local dir
    for dir in config data logs; do
        mkdir -p "$RUNTIME_DIR/$dir"
    done
}

stop_robot() {
    if [ -n "$ROBOT_PID" ] && kill -0 "$ROBOT_PID" 2>/dev/null; then
        kill -TERM "$ROBOT_PID"
        wait "$ROBOT_PID"
        echo "setup_robot: отримано сигнал, robot.py (PID $ROBOT_PID) коректно зупинено"
    else
        echo "setup_robot: отримано сигнал, дочірній процес уже не працює"
    fi
    exit 0
}

trap stop_robot SIGTERM SIGINT

export ROBOT_ENV="$MODE"

prepare_directories

echo "environment=$MODE" > "$RUNTIME_DIR/config/robot.conf"

python3 "$SCRIPT_DIR/robot.py" \
    >> "$RUNTIME_DIR/logs/robot.log" \
    2>> "$RUNTIME_DIR/logs/robot-error.log" &
ROBOT_PID=$!
echo "$ROBOT_PID" > "$RUNTIME_DIR/robot.pid"

wait "$ROBOT_PID"
