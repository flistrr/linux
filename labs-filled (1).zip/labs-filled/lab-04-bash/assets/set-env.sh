#!/usr/bin/env bash
# Тимчасовий файл для завдання 1 практики 4.
ROBOT_COLOR=blue
