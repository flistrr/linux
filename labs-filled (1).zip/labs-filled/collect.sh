#!/usr/bin/env bash
# Збирає результати всіх лаб у ~/labs-submit/ і пакує в ~/labs-submit.tar.gz.
#
#   bash labs-filled/collect.sh
#
# Нічого не змінює ні в ~/labs, ні в контейнері: лише копіює файли й запускає check-lab.sh
# (вони тільки читають стан). Наприкінці показує, які файли відсутні й де лишилися ⟦…⟧.

set -u

LABS="$HOME/labs"
OUT="$HOME/labs-submit"
UNITS="$HOME/.config/systemd/user"
NODE="$(id -un)-node"
MISSING=0

rm -rf "$OUT" && mkdir -p "$OUT"

ld() {
    local d
    for d in "$LABS"/lab-"$1"*; do
        if [ -d "$d" ] && [ ! -L "$d" ]; then echo "$d"; return; fi
    done
}

# grab <підкаталог у labs-submit> <шлях> — скопіювати файл або каталог
grab() {
    if [ -n "$2" ] && { [ -e "$2" ] || [ -L "$2" ]; }; then
        mkdir -p "$OUT/$1" && cp -a "$2" "$OUT/$1/"
    else
        echo "  [нема] $1: ${3:-${2/#$HOME/\~}}"
        MISSING=$((MISSING + 1))
    fi
}

# grabf <підкаталог> <каталог лаби> <ім'я файла> — знайти в каталозі лаби й скопіювати
grabf() {
    local f=""
    [ -n "$2" ] && f=$(find "$2" -maxdepth 3 -type f -name "$3" 2>/dev/null | head -n 1)
    grab "$1" "$f" "$3"
}

# check <підкаталог> <каталог лаби> — зберегти вивід самоперевірки
check() {
    local s
    for s in "$2/check-lab.sh" "$HOME/linux-course/$(basename -- "${2:-none}")/check-lab.sh"; do
        if [ -f "$s" ]; then
            mkdir -p "$OUT/$1"
            (cd "$(dirname -- "$s")" && timeout 120 bash ./check-lab.sh) > "$OUT/$1/check-lab.txt" 2>&1
            echo "  check-lab $1: $(tail -n 1 "$OUT/$1/check-lab.txt")"
            return
        fi
    done
}

have_node() { command -v lxc >/dev/null 2>&1 && lxc info "$NODE" >/dev/null 2>&1; }

echo "Збираю файли:"
L=$(ld 01); grabf 01 "$L" report.txt
L=$(ld 02); grab 02 "${L:+$L/workspace}" "workspace/"
L=$(ld 03); grabf 03 "$L" process-report.txt; grabf 03/logs "$L" worker.log; grabf 03/logs "$L" worker-error.log; check 03 "$L"
L=$(ld 04); grabf 04 "$L" setup_robot.sh
            R=""; [ -n "$L" ] && R=$(find "$L" -maxdepth 4 -type d -path '*/runtime/development' 2>/dev/null | head -n 1)
            grab 04/runtime "$R" "runtime/development/"
L=$(ld 05); grab 05 "$UNITS/robot.service"; grabf 05 "$L" service-report.txt; check 05 "$L"
L=$(ld 06); grab 06 "$UNITS/status.service"; grab 06 "$UNITS/status.timer"
            grabf 06 "$L" status.log; grabf 06 "$L" journal-report.txt; check 06 "$L"
L=$(ld 07); grabf 07 "$L" network-report.txt; check 07 "$L"
            if have_node; then lxc exec "$NODE" -- cat /etc/hosts > "$OUT/07/container-etc-hosts.txt" 2>&1
            else echo "  [нема] 07: /etc/hosts контейнера (lxc або $NODE недоступні)"; MISSING=$((MISSING + 1)); fi
L=$(ld 08); grabf 08 "$L" sockets-report.txt; grabf 08 "$L" client.log; check 08 "$L"
L=$(ld 09); grabf 09 "$L" ssh-report.txt; check 09 "$L"
L=$(ld 10); grabf 10 "$L" firewall-report.txt; grabf 10 "$L" client.log; check 10 "$L"
            if have_node && lxc file pull "$NODE/root/handshake.pcap" "$OUT/10/" 2>/dev/null; then :
            else echo "  [нема] 10: /root/handshake.pcap з контейнера"; MISSING=$((MISSING + 1)); fi

echo
UNFILLED=$(grep -rln -e '⟦' -e '<заповнити>' "$OUT" --include='*.txt' 2>/dev/null | grep -v '/check-lab.txt$' | sort)
if [ -n "$UNFILLED" ]; then
    echo "Ще не заповнено (⟦…⟧ або <заповнити>):"
    for f in $UNFILLED; do printf '  %s — %s шт.\n' "${f#$OUT/}" "$(grep -c -e '⟦' -e '<заповнити>' "$f")"; done
else
    echo "Незаповнених полів не знайдено."
fi
echo "Відсутніх файлів: $MISSING"

tar -czf "$HOME/labs-submit.tar.gz" -C "$HOME" labs-submit
echo
echo "Архів: ~/labs-submit.tar.gz ($(du -h "$HOME/labs-submit.tar.gz" | cut -f1))"
echo "Забрати на Мак (у терміналі Мака):"
echo "  scp $(id -un)@<адреса-сервера>:~/labs-submit.tar.gz ~/Downloads/"
