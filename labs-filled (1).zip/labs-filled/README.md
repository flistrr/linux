# Лаби 1–10 (Linux): заповнені звіти й готові файли

## Як запустити

**1. На Маці** (Terminal) — закинути архів на сервер і зайти:
```bash
scp ~/Downloads/labs-filled.zip <логін>@<сервер>:~/
# якщо Safari вже розпакував архів у папку:  scp -r ~/Downloads/labs-filled <логін>@<сервер>:~/
ssh <логін>@<сервер>
```

**2. На сервері** — розкласти файли й робити лаби:
```bash
unzip -q labs-filled.zip || python3 -m zipfile -e labs-filled.zip .   # без unzip теж працює
bash labs-filled/deploy.sh        # звіти й скрипти → ~/labs/…, симлінки lab-05/lab-06, chmod collect-status.sh
tmux new -s labs                  # якщо зв'язок впаде: ssh … і tmux attach -t labs

cd ~/labs/lab-01 && bash lab01-fill.sh     # лаба 1 — повністю автоматично
cd ~/labs/lab-02 && bash lab02-run.sh      # лаба 2 — повністю автоматично
# лаби 3–10: кроки з методички; звіти вже лежать на місці — заміни ⟦…⟧ своїми значеннями (nano)

bash ~/labs-filled/collect.sh     # зібрати все в ~/labs-submit.tar.gz + прогнати check-lab.sh
```
`collect.sh` наприкінці покаже, яких файлів бракує і в яких звітах ще лишилися ⟦…⟧.

**3. На Маці** — забрати результат:
```bash
scp <логін>@<сервер>:~/labs-submit.tar.gz ~/Downloads/
tar -xzf ~/Downloads/labs-submit.tar.gz -C ~/Downloads     # → ~/Downloads/labs-submit/01 … 10
```
Усередині по папці на лабу: звіти, логи, unit-файли, `workspace/` лаби 2, `runtime/` лаби 4,
`/etc/hosts` контейнера (7), `handshake.pcap` (10) і `check-lab.txt` з виводом самоперевірки.
Сам стан на сервері й у контейнері не чіпай після здачі — check-lab перевіряє його наживо.

## Що тут лежить

| Лаба | Файли | Що з ними робити |
|---|---|---|
| 1 | `lab01-fill.sh`, `assets/system-report.txt` | На сервері: `cd ~/labs/lab-01 && bash lab01-fill.sh` → готовий `report.txt` з твоїми значеннями й виводом команд. Скрипт лише читає систему. `system-report.txt` — той самий звіт з ⟦командами⟧ замість значень |
| 2 | `lab02-run.sh`, `report.example.txt` | `cd ~/labs/lab-02 && bash lab02-run.sh` — будує `workspace/` і пише `workspace/report.txt` з реальними виводами. `assets/` не змінює. `report.example.txt` — як це виглядало в тестовому прогоні (inode, дати й користувач там не твої) |
| 3 | `assets/process-report.txt` | Звіт; PID/PPID упиши свої. `logs/*.log` з'являться самі, коли пройдеш завдання |
| 4 | `assets/setup_robot.sh`, `set-env.sh`, `NOTES.txt` | Готовий скрипт без TODO (протестований: аргументи, trap, wait, запуск через `bin/setup-robot`). У NOTES — що казати про export/source |
| 5 | `systemd-user/robot.service`, `assets/service-report.txt` | Unit → `~/.config/systemd/user/` |
| 6 | `systemd-user/status.service`, `status.timer`, `assets/journal-report.txt` | Unit-и → `~/.config/systemd/user/` |
| 7–10 | `assets/*-report.txt` | Звіти; адреси, MAC, відбитки, PID упиши свої |

## Позначка ⟦…⟧

Там, де значення залежить від твоєї машини (IP, MAC, PID, час, відбиток), стоїть `⟦…⟧` з командою,
звідки його взяти. Усе інше (пояснення, коди виходу, стани, відповіді програм) уже заповнено й
звірено з кодом assets-скриптів.

**Перед здачею** перевір, що маркерів не лишилось — `check-lab.sh` шукає тільки `<заповнити>`, а `⟦` він не помітить:

```bash
grep -rn '⟦' ~/labs/*/assets/*-report.txt ~/labs/*/report.txt 2>/dev/null
```

## Косяки в самих методичках (виправ до початку)

```bash
# Лаба 5: методичка копіює в ~/labs/lab-05-services, а ExecStart і звіт чекають ~/labs/lab-05
ln -s lab-05-services ~/labs/lab-05

# Лаба 6: collect-status.sh пише в ~/labs/lab-06/status.log, а здати треба ~/labs/lab-06-journal/status.log
ln -s lab-06-journal ~/labs/lab-06
chmod +x ~/labs/lab-06-journal/collect-status.sh   # без x status.service впаде з 203/EXEC
```

- Лаба 5: якщо шлях у ExecStart неправильний, `python3` теж виходить з кодом **2** — легко сплутати зі
  «штатним» збоєм без ROBOT_ENV. Перевір, що служба реально `active (running)` на контрольній точці 1.
- Лаба 5, NRestarts: з `RestartSec=2` п'ять запусків займають ~10 с — це саме межа ліміту
  `StartLimitBurst=5 / StartLimitIntervalSec=10s`. Якщо за пів хвилини служба не впала в `failed`,
  а крутиться далі — це через цю межу; просто запиши NRestarts і що бачиш.
- Лаба 6: у `assets/robot.service` шлях `%h/labs/lab-06/robot.py` — не копіюй його поверх свого unit-а з лаби 5.
- Лаба 1 згадує `report_script.sh`, а лаби 3 і 8 — `check-lab.sh`: в архіві їх немає (мабуть, лежать на сервері).
- Лаба 9: після `PasswordAuthentication no` у `sshd_config` значення не зміниться — його перебиває файл у
  `/etc/ssh/sshd_config.d/` (sshd бере перше знайдене значення, а Include стоїть на початку).
  Шукати: `grep -ri passwordauthentication /etc/ssh/sshd_config.d/`.
- Лаба 10: перше повідомлення клієнта буде `timed out` (firewall), після `ufw allow 5000/tcp` —
  `Connection refused` (сервер слухає 127.0.0.1). check-lab вимагає в client.log обидва.
  Наприкінці лиши `5000/tcp ALLOW` і сервер на `--bind 0.0.0.0`.

## Якщо доступу до сервера курсу нема: VM на Маці

Усе нижче живе всередині VM; macOS не зачіпається, видаляється двома командами.
Multipass потребує macOS 14+.

```bash
# на Маці
brew install --cask multipass
multipass launch 24.04 --name linux-lab --cpus 2 --memory 4G --disk 20G
multipass shell linux-lab

# у VM (це твій «сервер»)
sudo snap install lxd 2>/dev/null; sudo lxd init --auto
sudo usermod -aG lxd "$USER"; exit          # перезайти: multipass shell linux-lab
lxc launch ubuntu:24.04 "$(id -un)-node"    # це твій «контейнер»
lxc exec "$(id -un)-node" -- apt-get install -y openssh-server ufw tcpdump bind9-dnsutils lsof

# прибрати все після курсу (на Маці)
multipass delete linux-lab && multipass purge
```

У такій копії не буде того, що викладач підклав на справжньому стенді (служба `robot-telemetry`
на 9100 у лабі 10, файл у `sshd_config.d` у лабі 9, мережа AWS у лабі 7), тож частина відповідей
відрізнятиметься. Для здачі звіти краще заповнювати на сервері курсу.
