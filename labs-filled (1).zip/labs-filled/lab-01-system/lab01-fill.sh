#!/usr/bin/env bash
# Практика 1: збирає відомості про систему й заповнює звіт.
# Лише читає /etc, /proc, /sys, /dev і запускає довідкові команди — нічого не змінює.
#
# Запуск зі СВОГО shell (того, який досліджуємо):
#   cd ~/labs/lab-01 && bash lab01-fill.sh            # звіт → ~/labs/lab-01/report.txt
#   bash lab01-fill.sh /інший/шлях/report.txt
#   bash lab01-fill.sh --preview                      # показати звіт із командами замість значень
#
# «Поточний shell» = процес, з якого запущено скрипт ($PPID скрипту), тому PID/PPID/cwd
# у звіті збігатимуться з тим, що покаже `echo $$`, `echo $PPID` у твоєму терміналі.

set -u

PREVIEW=0
if [ "${1:-}" = "--preview" ]; then PREVIEW=1; shift; fi
OUT="${1:-$HOME/labs/lab-01/report.txt}"

SH=$PPID                       # PID досліджуваного shell
WORKDIR=$(readlink "/proc/$SH/cwd" 2>/dev/null || pwd)

# v "<команда>" → значення з машини (або ⟦команда⟧ у режимі --preview)
v() {
    if [ "$PREVIEW" -eq 1 ]; then
        printf '⟦%s⟧' "${2:-$1}"
    else
        eval "$1" 2>/dev/null | sed -e 's/[[:space:]]*$//' | paste -sd ';' - | sed 's/;/; /g'
    fi
}

first_existing() { for p in "$@"; do [ -e "$p" ] && { echo "$p"; return; }; done; }
LOGF=$(first_existing /var/log/syslog /var/log/auth.log /var/log/dpkg.log /var/log/journal)
case "$LOGF" in
    */syslog)   LOGDESC="загальний текстовий журнал системи (rsyslog)" ;;
    */auth.log) LOGDESC="журнал автентифікації (входи, sudo, ssh)" ;;
    */dpkg.log) LOGDESC="журнал встановлення й видалення пакетів" ;;
    *)          LOGDESC="каталог бінарних журналів journald" ;;
esac
NETIF=$(ls /sys/class/net | grep -vx lo | head -n 1)
[ -n "$NETIF" ] || NETIF=lo
HOMEREL=${HOME#/}
if [ "$PREVIEW" -eq 1 ]; then
    NETIF='<інтерфейс, напр. ens5 або eth0>'; LOGF=/var/log/syslog
    LOGDESC="загальний текстовий журнал системи (rsyslog)"; HOMEREL='home/<логін>'
fi

report() {
cat <<EOF
# Звіт про Linux-систему

## Навігація

Робочий каталог: $(v "echo '$WORKDIR'" "вивід pwd")
Команда: pwd

Домашній каталог: $(v "echo '$HOME'" "cd ~ ; pwd")
Команда: cd /etc ; cd ../$HOMEREL/labs/lab-01 (повернення відносним шляхом) ; cd ~ ; pwd ; ls ~ та ls -a ~ — другий список додатково показує . , .. і приховані файли: $(v "ls -A ~ | grep '^\\.' | head -n 6" "ls -a ~ | grep '^\\.'")

Опція ls для зручного показу розмірів: -h (--human-readable), використовується разом із -l: ls -lh
Джерело довідки: man ls (розділ про -h, --human-readable); коротко — ls --help | grep -- '-h'

## Компоненти системи

Дистрибутив і версія: $(v ". /etc/os-release; echo \"\$PRETTY_NAME (\$VERSION_CODENAME)\"" "PRETTY_NAME з /etc/os-release")
Команда: cat /etc/os-release   (файл із /etc)

Ядро: $(v "uname -r")
Команда: uname -r ; cat /proc/version   (файл із /proc)

Архітектура: $(v "uname -m")
Команда: uname -m   (те саме є в uname -a та lscpu → Architecture)

Поточний shell: $(v "readlink /proc/$SH/exe" "readlink /proc/\$\$/exe"), \$SHELL = $(v "echo \"\$SHELL\"" "echo \$SHELL")
Команда: echo \$SHELL ; readlink /proc/\$\$/exe

CPU: $(v "grep -m1 'model name' /proc/cpuinfo | cut -d: -f2- | sed 's/^ *//'" "grep -m1 'model name' /proc/cpuinfo"); логічних CPU: $(v "nproc")
Команда: lscpu (спеціалізована команда) ; grep -m1 'model name' /proc/cpuinfo ; nproc

Оперативна пам’ять: $(v "free -h | awk '/^Mem:/ {print \$2}'" "free -h → стовпець total") (MemTotal: $(v "awk '/MemTotal/ {print \$2, \$3}' /proc/meminfo" "grep MemTotal /proc/meminfo"))
Команда: free -h ; grep MemTotal /proc/meminfo

## Системні каталоги

/etc — приклад і призначення: /etc/hostname — ім'я хоста ($(v "cat /etc/hostname" "cat /etc/hostname")); /etc загалом — системна конфігурація (текстові файли налаштувань)
/var/log — приклад і призначення: $LOGF — $LOGDESC; /var/log — змінні дані: журнали служб і системи
/proc/\$\$ — приклад і призначення: /proc/\$\$/status — стан процесу shell (Name, State, PPid, VmRSS…); каталог процесу, який ядро генерує на льоту
/sys/class/net — приклад і призначення: $NETIF — символічне посилання на пристрій мережевого інтерфейсу ($(v "readlink /sys/class/net/$NETIF" "readlink /sys/class/net/$NETIF")); sysfs показує пристрої та драйвери ядра
/dev — приклад і призначення: /dev/null — символьний пристрій «чорна діра» (усе записане відкидається, читання дає EOF); /dev містить файли пристроїв

PID shell: $(v "echo $SH" "echo \$\$")
PPID shell: $(v "ps -o ppid= -p $SH | tr -d ' '" "echo \$PPID") ($(v "ps -o comm= -p \$(ps -o ppid= -p $SH)" "ps -o comm= -p \$PPID"))
Робочий каталог через /proc: $(v "readlink /proc/$SH/cwd" "readlink /proc/\$\$/cwd")
Виконуваний файл через /proc: $(v "readlink /proc/$SH/exe" "readlink /proc/\$\$/exe")
Дескриптори 0, 1, 2: 0 = stdin → $(v "readlink /proc/$SH/fd/0" "readlink /proc/\$\$/fd/0"), 1 = stdout → $(v "readlink /proc/$SH/fd/1" "readlink /proc/\$\$/fd/1"), 2 = stderr → $(v "readlink /proc/$SH/fd/2" "readlink /proc/\$\$/fd/2"); у терміналі всі три — той самий псевдотермінал /dev/pts/N (ls -l /proc/\$\$/fd)

## Типи та пошук

Тип /etc/os-release: $(v "file /etc/os-release | cut -d: -f2- | sed 's/^ *//'" "file /etc/os-release") (у Ubuntu це символічне посилання на ../usr/lib/os-release; file -L покаже ASCII text)
Тип /bin/ls: $(v "file /bin/ls | cut -d: -f2- | sed 's/^ *//' | cut -d, -f1-3" "file /bin/ls")
Тип /etc: $(v "file /etc | cut -d: -f2- | sed 's/^ *//'" "file /etc")
Тип /dev/null: $(v "file /dev/null | cut -d: -f2- | sed 's/^ *//'" "file /dev/null")

Команда пошуку файлів .conf: find /etc -maxdepth 2 -type f -name "*.conf" 2>/dev/null | head -n 5
Перші результати: $(v "find /etc -maxdepth 2 -type f -name '*.conf' 2>/dev/null | head -n 5" "перші 5 рядків цієї команди")

Шлях до grep: $(v "which grep")
Команда: which grep

## Короткі пояснення

Чому дистрибутив і ядро визначаються окремо:
Ядро Linux і дистрибутив — різні компоненти з незалежними версіями. Дистрибутив (/etc/os-release)
описує набір програм користувацького простору, а uname -r показує ядро, яке реально запущене.
Той самий Ubuntu може працювати з різними ядрами (GA, HWE, хмарне -aws), а в контейнері
os-release належить контейнеру, тоді як ядро — спільне з хостом.

Чому /proc не є звичайним каталогом на диску:
/proc — віртуальна файлова система procfs. Її файли не зберігаються на диску (розмір 0):
ядро формує вміст у пам'яті в момент читання й показує поточний стан процесів і самого ядра
(/proc/\$\$/…, /proc/cpuinfo, /proc/meminfo). Після перезавантаження нічого «збереженого» там немає.
EOF
}

raw() {
    echo
    echo "## Вивід використаних команд"
    for c in "cat /etc/os-release" "uname -a" "cat /proc/version" "lscpu | head -n 15" "free -h" \
             "ls /etc | head -n 10" "ls /var/log" "ls /proc/$SH | head -n 15" "ls -l /sys/class/net" "ls /dev | head -n 15" \
             "ps -o pid,ppid,stat,cmd -p $SH" "ls -l /proc/$SH/fd" \
             "file /etc/os-release /bin/ls /etc /dev/null" "stat /etc/os-release" \
             "find /etc -maxdepth 2 -type f -name '*.conf' 2>/dev/null | head -n 5" "which grep" "df -h" "lsblk"; do
        printf '\n$ %s\n' "$c"
        eval "$c" 2>&1
    done
}

if [ "$PREVIEW" -eq 1 ]; then
    report
    exit 0
fi

mkdir -p "$(dirname -- "$OUT")"
{ report; raw; } > "$OUT"
echo "Звіт записано: $OUT"
