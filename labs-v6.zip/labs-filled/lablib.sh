# shellcheck shell=bash
# Спільне для labNN-run.sh: лог команд із виводом, команди в контейнері, підстановка у звіт.
# Підключається через «. lablib.sh», окремо не запускається.

set -u

LF=$(CDPATH='' cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
LABS="$HOME/labs"
ME=$(id -un)
NODE="$ME-node"
LOG=/dev/null
REPORT=""

# Каталог лаби NN у ~/labs (його створює deploy.sh)
labdir() {
    local d
    for d in "$LABS"/lab-"$1"*; do
        if [ -d "$d" ] && [ ! -L "$d" ]; then echo "$d"; return 0; fi
    done
    echo "Немає ~/labs/lab-$1… — спершу: bash ~/labs-filled/deploy.sh" >&2
    exit 1
}

start() {   # start <файл логу> <назва лаби>
    LOG=$1
    : > "$LOG"
    printf '# %s\n# %s  %s@%s\n' "$2" "$(date '+%F %T')" "$ME" "$(hostname)" | tee -a "$LOG"
}

say()  { printf '\n===== %s =====\n' "$*" | tee -a "$LOG"; }
note() { printf '%s\n' "$*" | tee -a "$LOG"; }

# Команда на «сервері» (VM). run — у підоболонці; here — у поточному shell (зберігає змінні, jobs, $!).
run() {
    printf '\n$ %s\n' "$1" | tee -a "$LOG"
    eval "$1" 2>&1 | tee -a "$LOG"
    return "${PIPESTATUS[0]}"
}
here() {
    local tmp rc
    printf '\n$ %s\n' "$1" | tee -a "$LOG"
    tmp=$(mktemp)
    eval "$1" > "$tmp" 2>&1
    rc=$?
    tee -a "$LOG" < "$tmp"
    rm -f "$tmp"
    return $rc
}

# Виконати один раз, показати й записати вивід у змінну: runv <змінна> <команда>
runv() {
    local __o
    printf '\n$ %s\n' "$2" | tee -a "$LOG"
    __o=$(eval "$2" 2>&1)
    __o=${__o//$'\r'/}
    printf '%s\n' "$__o" | tee -a "$LOG"
    printf -v "$1" '%s' "$__o"
}
nrunv() {
    local __o
    printf '\n[%s]# %s\n' "$NODE" "$2" | tee -a "$LOG"
    __o=$(lxc exec "$NODE" -- bash -c "$2" < /dev/null 2>&1)
    __o=${__o//$'\r'/}
    printf '%s\n' "$__o" | tee -a "$LOG"
    printf -v "$1" '%s' "$__o"
}

# Команда в контейнері (від root, як через lxc exec)
nrun() {
    printf '\n[%s]# %s\n' "$NODE" "$1" | tee -a "$LOG"
    lxc exec "$NODE" -- bash -c "$1" < /dev/null 2>&1 | tee -a "$LOG"
    return "${PIPESTATUS[0]}"
}
ncap() { lxc exec "$NODE" -- bash -c "$1" < /dev/null 2>/dev/null; }

# Довгоживучий процес у контейнері у фоні (як «окреме вікно контейнера»): nbg <команда> <файл виводу>
nbg() {
    printf '\n[%s]# %s      (окреме вікно; вивід → %s)\n' "$NODE" "$1" "$2" | tee -a "$LOG"
    lxc exec "$NODE" -- setsid -f bash -c "exec > '$2' 2>&1 < /dev/null; $1" < /dev/null
}

# Підстановка у звіт
setf() {
    if [ -z "${2// /}" ]; then note "  (немає значення для «$1» — лишаю підказку ⟦…⟧)"; return 0; fi
    python3 "$LF/fill.py" line "$REPORT" "$1" "$2" || note "  (не вдалося вписати «$1»)"
}
subf()   { python3 "$LF/fill.py" subst "$REPORT" "$1" "$2"; }
blockf() { python3 "$LF/fill.py" block "$REPORT" "$1" "$2" || note "  (не вдалося вписати блок «$1»)"; }

need_node() {
    if ! command -v lxc >/dev/null 2>&1 || ! lxc info "$NODE" >/dev/null 2>&1; then
        echo "Контейнер $NODE недоступний. Спершу bash ~/labs-filled/make-stand.sh, потім вийди й зайди у VM." >&2
        exit 1
    fi
}
need_sudo() { sudo -v || { echo "Потрібен sudo" >&2; exit 1; }; }
node_ip() { ncap "ip -4 -o addr show dev eth0" | awk '{print $4}' | cut -d/ -f1 | head -n 1; }
br_ip()   { ip -4 -o addr show dev lxdbr0 | awk '{print $4}' | cut -d/ -f1 | head -n 1; }

# Дочекатися, поки в контейнері з'явиться TCP-сокет LISTEN на порту
wait_listen() {
    local i
    for i in $(seq 30); do
        ncap "ss -Htln '( sport = :$1 )'" | grep -q . && return 0
        sleep 0.5
    done
    note "  (порт $1 у контейнері так і не перейшов у LISTEN)"
    return 1
}

run_check() {   # самоперевірка лаби, якщо є
    if [ -f "$1/check-lab.sh" ]; then
        say "Самоперевірка check-lab.sh"
        (cd "$1" && bash ./check-lab.sh) 2>&1 | tee -a "$LOG"
    fi
}

finish() {
    local n=0
    [ -n "$REPORT" ] && [ -f "$REPORT" ] && n=$(grep -c '⟦' "$REPORT")
    echo
    note "Готово. Лог: $LOG"
    if [ -n "$REPORT" ]; then
        note "Звіт: $REPORT — лишилось ⟦…⟧: $n"
        [ "$n" -gt 0 ] && grep -n '⟦' "$REPORT" | cut -c1-150 | tee -a "$LOG"
    fi
    return 0
}
