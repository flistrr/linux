#!/usr/bin/env bash
# Практика 9 — SSH: користувач admin1, перше підключення, ключі, тунель, rsync, захист sshd, невдалі входи.
#   bash ~/labs-filled/lab09-run.sh
# Лог: ~/labs/lab-09-ssh/lab09-log.txt. Звіт: assets/ssh-report.txt.
# Пароль admin1 генерується й зберігається в ~/labs/lab-09-ssh/admin1-password.txt.
# Підтвердження ключа хоста й паролі подає SSH_ASKPASS: на запит ssh відповідаємо відбитком,
# отриманим із контейнера через lxc exec, — якщо він не збігся, ssh не підключиться.
# Конфігурація SSH змінюється ЛИШЕ в контейнері.

. "$(dirname -- "$0")/lablib.sh"
L=$(labdir 09)
cd "$L" || exit 1
REPORT="$L/assets/ssh-report.txt"
start "$L/lab09-log.txt" "Практика 9. SSH і його захист"
need_node
N_IP=$(node_ip)
mkdir -p ~/.ssh && chmod 700 ~/.ssh

PWFILE="$L/admin1-password.txt"
if [ -s "$PWFILE" ]; then
    PW=$(cat "$PWFILE")
else
    PW="Lab9-$(tr -dc 'a-z0-9' < /dev/urandom | head -c 10)"
    (umask 077; printf '%s\n' "$PW" > "$PWFILE")
fi
note "Пароль admin1: $PW (збережено в $PWFILE)"

ASK=$(mktemp); ASKLOG=$(mktemp)
trap 'rm -f "$ASK" "$ASKLOG" "$ASKLOG".*' EXIT
export ASKLOG
cat > "$ASK" <<'EOF'
#!/bin/bash
# відповіді для ssh: ключ хоста — очікуваним відбитком (один раз), пароль — за налаштуваннями
printf '%s\n----\n' "$1" >> "$ASKLOG"
case "$1" in
    *"(yes/no"*)
        if [ -e "$ASKLOG.fp" ]; then echo no; else touch "$ASKLOG.fp"; echo "${ASK_FP:-no}"; fi ;;
    *assword*)
        [ "${ASK_PW:--}" = - ] && exit 1
        n=$(cat "$ASKLOG.n" 2>/dev/null || echo 0); echo $((n + 1)) > "$ASKLOG.n"
        if [ "$n" -lt "${ASK_WRONG:-0}" ]; then echo "wrong-password-$n"; else echo "$ASK_PW"; fi ;;
    *) exit 1 ;;
esac
EOF
chmod +x "$ASK"
# askrun <відбиток|-> <скільки разів дати неправильний пароль> <пароль|-> <команда…>
askrun() {
    local fp=$1 wrong=$2 pw=$3
    shift 3
    rm -f "$ASKLOG.n" "$ASKLOG.fp"
    ASK_FP=$fp ASK_WRONG=$wrong ASK_PW=$pw SSH_ASKPASS="$ASK" SSH_ASKPASS_REQUIRE=force DISPLAY="${DISPLAY:-:0}" "$@" < /dev/null
}
KEYSSH="ssh -o BatchMode=yes -o ConnectTimeout=10"

if ncap 'test -f /etc/ssh/sshd_config.bak'; then
    say "Повторний запуск: повертаю конфігурацію SSH контейнера до початкової"
    nrun 'cp /etc/ssh/sshd_config.bak /etc/ssh/sshd_config
for f in /etc/ssh/sshd_config.d/*.lab9bak; do [ -f "$f" ] && mv "$f" "${f%.lab9bak}"; done
sshd -t && { systemctl reload ssh || systemctl restart ssh; } && echo OK'
    # стартовий стан стенда: вхід за паролем дозволено окремим файлом у sshd_config.d
    if [ "$(ncap "sshd -T | awk '\$1 == \"passwordauthentication\" {print \$2}'")" != yes ]; then
        nrun "f=/etc/ssh/sshd_config.d/50-cloud-init.conf; if [ -f \$f ]; then sed -i -E 's/^([[:space:]]*PasswordAuthentication)[[:space:]]+no/\\1 yes/I' \$f; else echo 'PasswordAuthentication yes' > \$f; fi
sshd -t && { systemctl reload ssh || systemctl restart ssh; }; sshd -T | grep -E '^passwordauthentication '"
    fi
fi

say "Завдання 1. Адміністративний користувач"
note "(замість інтерактивного adduser: useradd + chpasswd — результат той самий)"
nrun "id admin1 > /dev/null 2>&1 || useradd -m -s /bin/bash admin1; usermod -aG sudo admin1; echo 'admin1:$PW' | chpasswd; id admin1; groups admin1"
nrunv SSHDT "sshd -T | grep -E '^(permitrootlogin|passwordauthentication|pubkeyauthentication) '"
for k in permitrootlogin passwordauthentication pubkeyauthentication; do
    setf "Чинне значення $k:" "$(printf '%s\n' "$SSHDT" | awk -v k="$k" '$1 == k {print $2}')"
done
nrun 'ip -4 addr show dev eth0'
setf "IPv4-адреса контейнера:" "$N_IP"

say "Завдання 2. Перше підключення"
nrunv FPL 'ssh-keygen -lf /etc/ssh/ssh_host_ed25519_key.pub'
FP=$(printf '%s\n' "$FPL" | awk '{print $2}')
setf "Відбиток, отриманий у контейнері через lxc exec:" "$FP"
run "ssh-keygen -R $N_IP 2>&1 | head -n 2; true"
: > "$ASKLOG"
note "(перше підключення за паролем: спершу неправильний пароль, потім правильний)"
runv FIRST "askrun '$FP' 1 '$PW' ssh -o PreferredAuthentications=password -o PubkeyAuthentication=no -o NumberOfPasswordPrompts=3 admin1@$N_IP hostname"
run "cat $ASKLOG"
if ! printf '%s\n' "$FIRST" | grep -qx "$(ncap hostname)"; then
    note "УВАГА: вхід за паролем не вдався — у контейнері заборонено PasswordAuthentication. Перевір sshd -T."
fi
SHOWN=$(grep -o 'key fingerprint is SHA256:[A-Za-z0-9+/=]*' "$ASKLOG" | head -n 1 | sed 's/key fingerprint is //')
KTYPE=$(grep -o '[A-Z0-9-]* key fingerprint is' "$ASKLOG" | head -n 1 | awk '{print $1}')
setf "Тип ключа хоста, запропонований ssh:" "$KTYPE"
setf "Відбиток, показаний ssh:" "$SHOWN"
if [ -n "$SHOWN" ] && [ "$SHOWN" = "$FP" ]; then setf "Чи збіглися відбитки:" "так"
elif [ -n "$SHOWN" ]; then setf "Чи збіглися відбитки:" "НІ — ssh показав $SHOWN, у контейнері $FP"; fi
run "ssh-keygen -F $N_IP | head -n 2"

say "Завдання 3. Вхід за ключем"
if [ -f ~/.ssh/id_ed25519 ]; then
    note "~/.ssh/id_ed25519 уже є — не перезаписую"
else
    run "ssh-keygen -t ed25519 -N '' -f ~/.ssh/id_ed25519"
fi
if ! ssh-keygen -y -P '' -f ~/.ssh/id_ed25519 > /dev/null 2>&1 && ! ssh-add -l > /dev/null 2>&1; then
    note "Ключ ~/.ssh/id_ed25519 захищений паролем. Виконай: eval \$(ssh-agent); ssh-add — і запусти скрипт знову."
    finish; exit 1
fi
run "askrun - 0 '$PW' ssh-copy-id -i ~/.ssh/id_ed25519.pub admin1@$N_IP"
nrunv PERMS "stat -c '%A %a %U:%G %n' /home/admin1/.ssh /home/admin1/.ssh/authorized_keys; cat /home/admin1/.ssh/authorized_keys"
setf "Права й власник каталогу ~/.ssh користувача admin1:" "$(printf '%s\n' "$PERMS" | awk 'NR == 1 {print $1 " (" $2 "), власник і група " $3}')"
setf "Права й власник файла authorized_keys:" "$(printf '%s\n' "$PERMS" | awk 'NR == 2 {print $1 " (" $2 "), власник і група " $3}')"
runv HN "$KEYSSH admin1@$N_IP hostname"
setf "Команда, виконана в контейнері без відкриття сеансу, і її результат:" "ssh admin1@$N_IP hostname → $HN"
nrun 'chmod g+w /home/admin1/.ssh/authorized_keys; ls -l /home/admin1/.ssh/authorized_keys'
: > "$ASKLOG"
runv V "askrun - 0 - ssh -v -o ConnectTimeout=10 admin1@$N_IP true"
# rejected <вивід ssh -v> → 0, якщо ключ відхилено
key_rejected() { ! printf '%s\n' "$1" | grep -q 'Authenticated to .* using "publickey"'; }
verbose_lines() {
    printf '%s\n' "$1" | awk '/Offering public key/ {o = $0; next}
        o != "" && /Authentications that can continue/ {print o; print; o = ""; f = 1; next}
        f && /Next authentication method/ {print; exit}' | paste -sd '|' - | sed 's/|/ → /g'
}
GW_ACCEPTED=0
if key_rejected "$V"; then
    PWPROMPT=$(grep -o "[^ ]*'s password:" "$ASKLOG" | head -n 1)
    setf "Результат входу після надання групі права запису на authorized_keys:" "ключ відхилено — ssh перейшов до входу за паролем і запитав «$PWPROMPT»"
    setf "Рядок детального виводу ssh, що відповідає цьому результату:" "$(verbose_lines "$V")"
else
    GW_ACCEPTED=1
    note "Ключ ПРИЙНЯТО й з g+w: OpenSSH в Ubuntu (Debian-патч user-group-modes) дозволяє запис групі,"
    note "якщо це особиста група користувача без інших членів (група admin1 — саме така)."
    note "Щоб побачити відмову StrictModes, даємо право запису іншим (o+w):"
    nrun 'chmod o+w /home/admin1/.ssh/authorized_keys; ls -l /home/admin1/.ssh/authorized_keys; getent group admin1'
    : > "$ASKLOG"
    runv V "askrun - 0 - ssh -v -o ConnectTimeout=10 admin1@$N_IP true"
    PWPROMPT=$(grep -o "[^ ]*'s password:" "$ASKLOG" | head -n 1)
    if key_rejected "$V"; then
        setf "Результат входу після надання групі права запису на authorized_keys:" "з g+w ключ прийнято: OpenSSH в Ubuntu (Debian-патч user-group-modes) дозволяє запис групі, якщо це особиста група admin1 без інших членів. Після chmod o+w (запис іншим) ключ відхилено — ssh перейшов до входу за паролем і запитав «$PWPROMPT»"
        setf "Рядок детального виводу ssh, що відповідає цьому результату:" "з g+w: «Authenticated … using \"publickey\"»; з o+w: $(verbose_lines "$V")"
    else
        setf "Результат входу після надання групі права запису на authorized_keys:" "ключ прийнято і з g+w, і з o+w — перевір StrictModes у sshd -T"
    fi
fi
nrunv J "journalctl -u ssh -n 120 --no-pager | grep 'bad ownership or modes' | tail -n 1"
setf "Запис журналу служби SSH у контейнері, що пояснює причину:" "$J"
nrun 'chmod 600 /home/admin1/.ssh/authorized_keys; ls -l /home/admin1/.ssh/authorized_keys'
run "$KEYSSH admin1@$N_IP 'echo вхід за ключем знову працює'"

say "Завдання 4. Локальний тунель"
nbg 'python3 -m http.server 8000 --bind 127.0.0.1 --directory /home/shared/labs/lab-09-ssh/assets/dashboard' /tmp/http9.log
wait_listen 8000
runv D "curl -sS -m 5 http://$N_IP:8000/ -o /dev/null"
setf "Результат прямого звернення із сервера до порту 8000 контейнера:" "відмова — $D: HTTP-сервер слухає лише 127.0.0.1 контейнера"
PORT=$((10000 + $(id -u)))
setf "Локальний порт тунелю на сервері:" "$PORT (10000 + UID $(id -u))"
run "$KEYSSH -f -N -o ExitOnForwardFailure=yes -L $PORT:127.0.0.1:8000 admin1@$N_IP"
sleep 1
run "curl -s -m 5 http://127.0.0.1:$PORT/ | head -n 5"
runv TS "ss -tlnp | grep ':$PORT '"
setf "Адреса прослуховування тунелю на сервері:" "$(printf '%s\n' "$TS" | awk '{print $4}' | paste -sd ',' - | sed 's/,/ і /g') — процес $(printf '%s\n' "$TS" | grep -o '"[^"]*",pid=[0-9]*' | head -n 1 | sed 's/"\([^"]*\)",pid=\([0-9]*\)/\1 (pid \2)/')"
nrunv HL 'cat /tmp/http9.log'
setf "Адреса клієнта, яку вивів HTTP-сервер у контейнері:" "$(printf '%s\n' "$HL" | grep -m 1 '"GET' | awk '{print $1}')"
TPID=$(pgrep -f -- "-L $PORT:127.0.0.1:8000" | head -n 1)
[ -n "$TPID" ] && run "kill $TPID"
ncap "pkill -f 'http.server 8000'"

say "Завдання 5. Передача робочого каталогу"
run 'du -sh assets/ros2_ws'
setf "Розмір каталогу ros2_ws на сервері:" "$(du -sh assets/ros2_ws | cut -f1)"
run 'tar -czf ros2_ws.tar.gz --exclude=build --exclude=install --exclude=log -C assets ros2_ws && tar -tzf ros2_ws.tar.gz && ls -lh ros2_ws.tar.gz'
setf "Розмір архіву:" "$(ls -lh ros2_ws.tar.gz | awk '{print $5}') (tar -czf ros2_ws.tar.gz --exclude=build --exclude=install --exclude=log -C assets ros2_ws)"
run "scp -o BatchMode=yes ros2_ws.tar.gz admin1@$N_IP: && $KEYSSH admin1@$N_IP 'tar -xzf ros2_ws.tar.gz && find ros2_ws -maxdepth 3 | sort'"
PARAMS=assets/ros2_ws/src/robot_pkg/config/params.yaml
ORIG=/home/shared/labs/lab-09-ssh/assets/ros2_ws/src/robot_pkg/config/params.yaml
if [ ! -f "$ORIG" ] || cmp -s "$PARAMS" "$ORIG"; then
    run "sed -i 's/max_speed: 0.5 /max_speed: 0.7 /' $PARAMS"
    cmp -s "$PARAMS" "$ORIG" && run "echo '# змінено для практики 9' >> $PARAMS"
fi
run "grep -n max_speed $PARAMS"
RSYNC="rsync -avz -e 'ssh -o BatchMode=yes' --exclude=build --exclude=install --exclude=log assets/ros2_ws/ admin1@$N_IP:ros2_ws/"
runv RS "${RSYNC/rsync -avz/rsync -avz --dry-run}"
setf "Файли, які синхронізація в режимі перевірки збиралася передати:" "$(printf '%s\n' "$RS" | awk '/file list/ {f = 1; next} f && NF == 0 {exit} f {print}' | paste -sd ',' - | sed 's/,/, /g')"
run "$RSYNC"
run "$KEYSSH admin1@$N_IP 'grep max_speed ros2_ws/src/robot_pkg/config/params.yaml'"

say "Завдання 6. Заборона входу root і входу за паролем"
note "(вікно lxc exec — резервний доступ: зміни SSH робляться в контейнері через нього)"
nrun 'cp -n /etc/ssh/sshd_config /etc/ssh/sshd_config.bak; ls -l /etc/ssh/sshd_config*'
nrun "sed -i -E 's/^#?[[:space:]]*PermitRootLogin[[:space:]].*/PermitRootLogin no/; s/^#?[[:space:]]*PasswordAuthentication[[:space:]].*/PasswordAuthentication no/' /etc/ssh/sshd_config
grep -q '^PermitRootLogin no' /etc/ssh/sshd_config || echo 'PermitRootLogin no' >> /etc/ssh/sshd_config
grep -q '^PasswordAuthentication no' /etc/ssh/sshd_config || echo 'PasswordAuthentication no' >> /etc/ssh/sshd_config
grep -nE '^(PermitRootLogin|PasswordAuthentication|Include)' /etc/ssh/sshd_config"
nrun 'sshd -t && { systemctl reload ssh || systemctl restart ssh; } && echo "зміни застосовано без розриву сеансів"'
nrunv T1 "sshd -T | grep -E '^(permitrootlogin|passwordauthentication) '"
setf "Чинні значення permitrootlogin і passwordauthentication одразу після першого застосування змін:" "$(printf '%s\n' "$T1" | paste -sd ',' - | sed 's/,/, /g')"
nrunv OV "grep -rniE '^[[:space:]]*(passwordauthentication|permitrootlogin)[[:space:]]+yes' /etc/ssh/sshd_config.d/; true"
OVFILES=$(printf '%s\n' "$OV" | grep -o '^/etc/ssh/sshd_config.d/[^:]*' | sort -u)
if [ -n "$OVFILES" ]; then
    setf "Файл, значення в якому скасовувало зміну:" "$(printf '%s\n' "$OVFILES" | paste -sd ',' -) (рядок: $(printf '%s\n' "$OV" | head -n 1 | cut -d: -f3-))"
    nrun "for f in $(printf '%s ' $OVFILES); do cp -n \"\$f\" \"\$f.lab9bak\"; done; sed -i -E 's/^([[:space:]]*PasswordAuthentication)[[:space:]]+yes/\\1 no/I; s/^([[:space:]]*PermitRootLogin)[[:space:]]+yes/\\1 no/I' $(printf '%s ' $OVFILES); grep -rniE 'passwordauthentication|permitrootlogin' /etc/ssh/sshd_config.d/"
    nrun 'sshd -t && { systemctl reload ssh || systemctl restart ssh; } && echo OK'
else
    setf "Файл, значення в якому скасовувало зміну:" "такого файла немає — обидва значення застосувалися з першого разу"
fi
nrun "sshd -T | grep -E '^(permitrootlogin|passwordauthentication) '"
note "(перевірка в «новому вікні»:)"
if runv K "$KEYSSH admin1@$N_IP 'echo вхід за ключем: OK'"; then
    setf "Результат входу admin1 за ключем у новому вікні:" "вхід успішний, пароль не запитується"
fi
runv NOK "$KEYSSH -o PubkeyAuthentication=no admin1@$N_IP true"
setf "Результат входу admin1 з відмовою від ключа:" "відмова — «$(printf '%s\n' "$NOK" | grep -m 1 'Permission denied')» (ssh -o PubkeyAuthentication=no admin1@$N_IP)"

say "Завдання 7. Невдалі спроби входу"
nrunv FL "journalctl -u ssh --since today --no-pager | grep -E 'Failed password for admin1|Connection closed by authenticating user admin1'"
setf "Запис журналу про спробу з неправильним паролем (завдання 2):" "$(printf '%s\n' "$FL" | grep -m 1 'Failed password for admin1')"
setf "Запис журналу про відхилену спробу входу лише за паролем (завдання 6):" "$(printf '%s\n' "$FL" | grep 'Connection closed by authenticating user admin1' | tail -n 1)"
nrunv LB 'lastb -n 10 2>/dev/null | head -n 10'
setf "Записи, які показав lastb:" "$(printf '%s\n' "$LB" | grep -m 1 admin1)"

run_check "$L"
finish
