#!/usr/bin/env bash
# Практика 3 — процеси, стани, потоки, сигнали.   bash ~/labs-filled/lab03-run.sh
# Працює в ~/labs/lab-03/assets. Пише лог ~/labs/lab-03/lab03-log.txt і вписує PID/PPID у звіт.
# Ctrl+Z і Ctrl+C емулюються сигналами SIGTSTP і SIGINT — саме їх надсилає термінал.

. "$(dirname -- "$0")/lablib.sh"
L=$(labdir 03)
cd "$L/assets" || exit 1
REPORT="$L/assets/process-report.txt"
start "$L/lab03-log.txt" "Практика 3. Процеси та сигнали"
[ -f worker.py ] || { echo "Немає worker.py у $PWD" >&2; exit 1; }
set -m      # керування завданнями (jobs, bg) усередині скрипту

say "Завдання 1. Foreground, background, Ctrl+Z, Ctrl+C"
note "(у скрипті Ctrl+Z = kill -TSTP, Ctrl+C = kill -INT; термінал надсилає ті самі сигнали)"
here 'python3 worker.py > /dev/null 2>&1 &'
sleep 2
here 'kill -TSTP %1          # = Ctrl+Z'
sleep 0.5
here 'jobs -l'
here 'bg %1'
sleep 1
here 'jobs -l'
note "(fg %1 → Ctrl+C:)"
here 'kill -INT %1; wait %1; echo "echo \$? → $?"'

say "Завдання 2. PID, PPID, стани"
here 'python3 worker.py > /dev/null 2>&1 & echo $! > worker.pid'
P=$(cat worker.pid)
sleep 1
run "ps -o pid,ppid,stat,tty,cmd -p $P"
run 'pgrep -af "python3 worker.py"'
PP=$(ps -o ppid= -p "$P" | tr -d ' ')
ST1=$(ps -o stat= -p "$P" | tr -d ' ')
here "kill -SIGSTOP $P"
sleep 0.5
run "ps -o pid,stat -p $P"
ST2=$(ps -o stat= -p "$P" | tr -d ' ')
here "kill -SIGCONT $P"
sleep 0.5
run "ps -o pid,stat -p $P"
here "kill $P; wait $P; echo \"код: \$?\""

say "Завдання 3. Стандартні потоки"
run 'mkdir -p logs'
here 'python3 worker.py >> logs/worker.log 2>> logs/worker-error.log & echo $! > worker.pid'
sleep 7
run 'tail -n 5 logs/worker.log'
run 'tail -n 5 logs/worker-error.log'

say "Завдання 4. SIGTERM і SIGKILL"
here 'kill -SIGTERM "$(cat worker.pid)"; wait "$(cat worker.pid)"; echo "код: $?"'
TERM_RC=$(tail -n 1 "$LOG" | grep -o '[0-9]\+$')
run 'tail -n 3 logs/worker.log'
here 'python3 worker.py >> logs/worker.log 2>> logs/worker-error.log & echo $! > worker.pid'
sleep 3
here 'kill -SIGKILL "$(cat worker.pid)"; wait "$(cat worker.pid)"; echo "код: $?"'
KILL_RC=$(tail -n 1 "$LOG" | grep -o '[0-9]\+$')
run 'tail -n 3 logs/worker.log'
run 'ps -p "$(cat worker.pid)" || echo "(порожньо після заголовка — процес завершено)"'

say "Звіт"
setf "PID:" "$P (cat worker.pid — PID, збережений одразу після запуску: python3 worker.py & echo \$! > worker.pid)"
setf "PPID:" "$PP — батьківський процес: shell, з якого запущено програму (тут bash скрипту lab03-run.sh; вручну — твій shell, echo \$\$)"
setf "Стан під час звичайної роботи:" "$ST1 — interruptible sleep: процес майже весь час спить у time.sleep(1) (без «+», бо працює у background)"
setf "Стан після SIGSTOP:" "$ST2 — stopped; після kill -SIGCONT знову S"
[ "$TERM_RC" = 0 ] || note "  УВАГА: після SIGTERM код $TERM_RC, а не 0 — перевір звіт"
[ "$KILL_RC" = 137 ] || note "  УВАГА: після SIGKILL код $KILL_RC, а не 137 — перевір звіт"
run_check "$HOME/linux-course/lab-03"
finish
