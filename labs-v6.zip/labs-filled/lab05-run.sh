#!/usr/bin/env bash
# Практика 5 — systemd: завантаження, служби, власна служба robot, збої й перезапуск.
#   bash ~/labs-filled/lab05-run.sh
# Лог: ~/labs/lab-05/lab05-log.txt. Звіт: ~/labs/lab-05/service-report.txt.
# Наприкінці служба robot працює (вона потрібна в лабі 6).

. "$(dirname -- "$0")/lablib.sh"
L=$(labdir 05)
REPORT="$L/service-report.txt"
UNIT="$HOME/.config/systemd/user/robot.service"
start "$L/lab05-log.txt" "Практика 5. systemd і власна служба"
if [ ! -f "$HOME/labs/lab-05/assets/robot.py" ]; then
    echo "Немає ~/labs/lab-05/assets/robot.py — запусти bash ~/labs-filled/deploy.sh" >&2
    exit 1
fi
need_sudo
show() { systemctl --user show robot -p "$1" --value 2>/dev/null; }

say "Завдання 1. Завантаження системи"
run 'systemd-analyze'
SA=$(systemd-analyze 2>/dev/null | head -n 1)
if [[ $SA == *" = "* ]]; then
    setf "Загальний час завантаження:" "${SA##* = }"
    PARTS=${SA#Startup finished in }
    setf "Час ядра і час простору користувача окремо:" "${PARTS% = *}"
else
    note "  (systemd-analyze ще не має підсумку — система не завершила завантаження; повтори пізніше)"
fi
run 'systemd-analyze blame | head -n 5'
SLOW=$(systemd-analyze blame 2>/dev/null | head -n 1 | sed 's/^ *//')
[ -n "$SLOW" ] && setf "Найповільніший unit і його час:" "$SLOW"
run 'systemd-analyze critical-chain --no-pager | head -n 20'
run 'sudo dmesg | head -n 20'
run "sudo dmesg | grep -i -m 5 -E 'virtio|vda|nvme|sda|enp|eth|usb'"
DEV=$(sudo dmesg 2>/dev/null | grep -i -m 1 -E 'virtio|vda|nvme|sda|enp|eth|usb' | sed 's/^\[ *[0-9.]*\] //')
[ -n "$DEV" ] && setf "Рядок ядра про виявлений пристрій:" "$DEV"

say "Завдання 2. Наявні служби"
run 'systemctl status ssh --no-pager -n 0'
SSHST=$(systemctl status ssh --no-pager -n 0 2>/dev/null)
LOADED=$(printf '%s\n' "$SSHST" | grep -m 1 'Loaded:' | sed 's/^ *//')
ACTIVE=$(printf '%s\n' "$SSHST" | grep -m 1 'Active:' | sed 's/^ *//')
[ -n "$LOADED" ] && setf "Рядок Loaded служби ssh:" "$LOADED"
[ -n "$ACTIVE" ] && setf "Рядок Active служби ssh:" "$ACTIVE"
SSHPID=$(systemctl show ssh -p MainPID --value 2>/dev/null)
if [ "${SSHPID:-0}" -gt 0 ] 2>/dev/null; then
    setf "Main PID служби ssh:" "Main PID: $SSHPID ($(ps -o comm= -p "$SSHPID"))"
else
    setf "Main PID служби ssh:" "немає — sshd зараз не запущений: у Ubuntu 24.04 його запускає ssh.socket при першому підключенні (рядок TriggeredBy: ssh.socket)"
fi
run 'systemctl cat ssh --no-pager | head -n 20'
FRAG=$(systemctl show ssh -p FragmentPath --value 2>/dev/null)
[ -n "$FRAG" ] && setf "Шлях до unit-файла служби ssh:" "$FRAG (перший рядок-коментар у виводі systemctl cat; якщо є drop-in, його шлях буде нижче)"
run 'systemctl list-units --type=service --state=running --no-pager --no-legend --plain | head -n 40'
run 'systemctl list-unit-files --type=service --state=enabled --no-pager --no-legend'
CMP='comm -13 <(systemctl list-units --type=service --state=running --no-legend --plain | awk '\''{print $1}'\'' | sort) <(systemctl list-unit-files --type=service --state=enabled --no-legend | awk '\''{print $1}'\'' | sort)'
run "$CMP"
CAND=$(eval "$CMP" 2>/dev/null | grep -v '@\.service$' | head -n 1)
if [ -n "$CAND" ]; then
    run "systemctl status $CAND --no-pager -n 0"
    CST=$(systemctl show "$CAND" -p ActiveState -p SubState --value 2>/dev/null | paste -sd ' ' -)
    setf "Служба, яка увімкнена, але не працює:" "$CAND — увімкнена (enabled), але стан $CST, тобто процесу зараз немає"
fi

say "Завдання 3. Власний unit-файл"
mkdir -p "$(dirname -- "$UNIT")"
if [ -f "$UNIT" ]; then cp "$UNIT" "$UNIT.bak"; note "(наявний robot.service збережено як robot.service.bak)"; fi
cat > "$UNIT" <<'EOF'
[Unit]
Description=Навчальна служба robot (практика 5)

[Service]
ExecStart=/usr/bin/python3 %h/labs/lab-05/assets/robot.py
Environment=ROBOT_ENV=lab

[Install]
WantedBy=default.target
EOF
run "cat $UNIT"
run 'systemctl --user daemon-reload'
run 'systemctl --user restart robot'
sleep 2
run 'systemctl --user status robot --no-pager -n 5'
if [ "$(systemctl --user is-active robot)" != active ]; then
    note "УВАГА: служба robot не запустилась — дивись status вище (найчастіше неправильний шлях у ExecStart)."
    finish; exit 1
fi
setf "Main PID служби robot:" "$(show MainPID)"
subf "⟦логін⟧" "$ME"

say "Завдання 4.1. Збій без змінної середовища"
run "sed -i '/^Environment=ROBOT_ENV=lab\$/d' $UNIT && cat $UNIT"
run 'systemctl --user daemon-reload'
run 'systemctl --user restart robot'
sleep 2
run 'systemctl --user status robot --no-pager -n 5'
RC=$(show ExecMainStatus); RES=$(show Result)
setf "Код завершення програми без змінної ROBOT_ENV:" "$RC (у status: «Main process exited, code=exited, status=$RC/…»; у журналі — «robot: змінна ROBOT_ENV не встановлена»)"
setf "Значення поля Result у виводі status:" "$RES (рядок «Failed with result '$RES'»)"

say "Завдання 4.2. Політика перезапуску"
run "sed -i '/^ExecStart=/a Restart=on-failure\nRestartSec=2' $UNIT && cat $UNIT"
run 'systemctl --user daemon-reload'
run 'systemctl --user restart robot'
for i in $(seq 15); do
    sleep 3
    ST=$(show ActiveState)
    note "  через $((i * 3)) с: ActiveState=$ST NRestarts=$(show NRestarts)"
    [ "$ST" = failed ] && break
done
run 'systemctl --user status robot --no-pager -n 8'
NR=$(show NRestarts); RES=$(show Result)
if [ "$RES" = start-limit-hit ]; then
    setf "Значення NRestarts після серії невдалих запусків:" "$NR — після кількох спроб systemd зупинився з Result=start-limit-hit («Start request repeated too quickly»): ліміт — не більше StartLimitBurst=5 запусків за StartLimitIntervalSec=10s"
else
    setf "Значення NRestarts після серії невдалих запусків:" "$NR за ~45 с, Result=$RES — служба далі перезапускалась: з RestartSec=2 п'ять запусків займають ~10 с, якраз межа ліміту StartLimitBurst=5 / StartLimitIntervalSec=10s, тож він не спрацював"
fi

say "Завдання 4.3. Повернути змінну середовища"
run "sed -i '/^ExecStart=/a Environment=ROBOT_ENV=lab' $UNIT && cat $UNIT"
run 'systemctl --user daemon-reload'
run 'systemctl --user reset-failed robot'
run 'systemctl --user restart robot'
sleep 2
run 'systemctl --user status robot --no-pager -n 3'

say "Завдання 4.4. SIGKILL"
MP1=$(show MainPID); NR1=$(show NRestarts)
here "kill -SIGKILL $MP1"
sleep 4
run 'systemctl --user status robot --no-pager -n 5'
MP2=$(show MainPID); NR2=$(show NRestarts)
setf "Стан служби після kill -SIGKILL:" "$(show ActiveState) ($(show SubState)) — приблизно через 2 с (RestartSec=2) systemd сам запустив службу знову"
if [ "$MP1" != "$MP2" ]; then
    setf "Main PID до надсилання сигналу і після нього:" "до: $MP1 → після: $MP2 (новий процес); NRestarts: $NR1 → $NR2"
else
    setf "Main PID до надсилання сигналу і після нього:" "до: $MP1 → після: $MP2 — PID не змінився, перевір status вище; NRestarts: $NR1 → $NR2"
fi

say "Завдання 4.5. stop не перезапускає"
NR3=$(show NRestarts)
run 'systemctl --user stop robot'
sleep 4
run 'systemctl --user status robot --no-pager -n 3'
note "NRestarts до stop: $NR3, після: $(show NRestarts) — перезапуску не було"
run 'systemctl --user start robot'
run 'systemctl --user is-active robot'

run_check "$L"
finish
