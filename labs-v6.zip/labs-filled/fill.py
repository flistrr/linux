#!/usr/bin/env python3
"""Підстановка значень у звіти лаб.

  fill.py line  <звіт> <початок рядка> <значення>   — рядок, що починається з <початок>, стає «<початок> <значення>»
  fill.py subst <звіт> <старе> <нове>               — замінити всі входження
  fill.py block <звіт> <заголовок> <текст>          — рядки після заголовка до порожнього рядка замінити текстом
"""
import sys


def main() -> int:
    if len(sys.argv) != 5:
        print(__doc__, file=sys.stderr)
        return 2
    mode, path, a, b = sys.argv[1:5]
    b = b.replace("\r", "")
    with open(path, encoding="utf-8") as fh:
        lines = fh.read().split("\n")

    if mode == "line":
        value = " | ".join(x.strip() for x in b.strip().splitlines() if x.strip())
        for i, line in enumerate(lines):
            if line.startswith(a):
                lines[i] = f"{a} {value}".rstrip()
                break
        else:
            print(f"fill: рядок «{a}» не знайдено в {path}", file=sys.stderr)
            return 1
    elif mode == "subst":
        text = "\n".join(lines)
        if a not in text:
            return 0
        lines = text.replace(a, b).split("\n")
    elif mode == "block":
        for i, line in enumerate(lines):
            if line.startswith(a):
                j = i + 1
                while j < len(lines) and lines[j].strip():
                    j += 1
                lines[i + 1:j] = [x.rstrip() for x in b.strip("\n").split("\n")]
                break
        else:
            print(f"fill: заголовок «{a}» не знайдено в {path}", file=sys.stderr)
            return 1
    else:
        print(__doc__, file=sys.stderr)
        return 2

    with open(path, "w", encoding="utf-8") as fh:
        fh.write("\n".join(lines))
    return 0


if __name__ == "__main__":
    sys.exit(main())
