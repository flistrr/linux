#!/usr/bin/env bash
# Практика 8 — порти, сокети, TCP вручну, HTTP, сервер робота, UDP.
#   bash ~/labs-filled/lab08-run.sh
# Лог: ~/labs/lab-08-sockets/lab08-log.txt. Звіт: assets/sockets-report.txt. Клієнт пише assets/client.log.
# «Вікна контейнера» з методички тут — фонові процеси в контейнері.

. "$(dirname -- "$0")/lablib.sh"
L=$(labdir 08)
cd "$L" || exit 1
REPORT="$L/assets/sockets-report.txt"
start "$L/lab08-log.txt" "Практика 8. Порти, сокети, TCP і UDP"
need_node
need_sudo
N_IP=$(node_ip); BR_IP=$(br_ip)
note "контейнер: $N_IP, сервер у lxdbr0: $BR_IP"
nrun 'cp /home/shared/labs/lab-08-sockets/assets/robot_server.py ~/ && ls -l ~/robot_server.py'
users_of() { grep -o '"[^"]*",pid=[0-9]*' | sed 's/"\([^"]*\)",pid=\([0-9]*\)/\1 (pid \2)/' | sort -u | paste -sd ',' - | sed 's/,/, /g'; }

say "Завдання 1. Відкриті порти сервера"
run 'sudo ss -tulnp'
SS=$(sudo ss -Htulnp)
L22=$(printf '%s\n' "$SS" | awk '$1 == "tcp" && $5 ~ /:22$/')
if [ -n "$L22" ]; then
setf "Процес, що очікує з'єднань на TCP-порту 22:" "$(printf '%s\n' "$L22" | users_of)"
setf "Адреса прив'язки цього сокета:" "$(printf '%s\n' "$L22" | awk '{print $5}' | paste -sd ',' - | sed 's/,/ і /g')"
fi
LO=$(printf '%s\n' "$SS" | awk '$5 ~ /^127\./ || $5 ~ /^\[::1\]/')
LOPROG=$(printf '%s\n' "$LO" | grep -o '"[^"]*"' | head -n 1 | tr -d '"')
printf '%s\n' "$LO" | grep -q '"systemd-resolve"' && LOPROG=systemd-resolve
if [ -n "$LOPROG" ]; then
    setf "Служба, доступна лише через loopback, її адреса й порт:" "$LOPROG — $(printf '%s\n' "$LO" | grep "\"$LOPROG\"" | awk '{print $5 "/" $1}' | sort -u | paste -sd ',' - | sed 's/,/, /g')"
fi
BR=$(printf '%s\n' "$SS" | grep -E "$BR_IP:|%lxdbr0:")
BRPROG=$(printf '%s\n' "$BR" | grep -o '"[^"]*"' | head -n 1 | tr -d '"')
if [ -n "$BRPROG" ]; then
    setf "Служба, прив'язана до адреси сервера в мережі lxdbr0:" "$BRPROG — DNS- і DHCP-сервер, який LXD запускає для контейнерів"
    setf "Порти й протоколи цієї служби:" "$(printf '%s\n' "$BR" | awk '{n = split($5, a, ":"); print a[n] "/" $1 " на " substr($5, 1, length($5) - length(a[n]) - 1)}' | sort -u | paste -sd ',' - | sed 's/,/; /g')"
fi

say "Завдання 2. TCP-з'єднання вручну"
nbg 'sleep 30 | nc -l 5000' /tmp/nc5000.out
wait_listen 5000
nrunv LST "ss -tln '( sport = :5000 )'"
setf "Стан сокета порту 5000 у контейнері до підключення:" "$(printf '%s\n' "$LST" | awk 'NR > 1 {print $1 " (" $4 ", віддалена " $5 ")"; exit}')"
here '( printf "hello from server\n"; sleep 8 ) | nc "$N_IP" 5000 & NCPID=$!'
sleep 2
runv SRVSS "ss -tn '( dport = :5000 )'"
nrunv NODESS "ss -tnp '( sport = :5000 )'"
SRV=$(printf '%s\n' "$SRVSS" | awk '$1 == "ESTAB" {print $4 " -> " $5; exit}')
NOD=$(printf '%s\n' "$NODESS" | awk '$1 == "ESTAB" {print $4 " -> " $5; exit}')
EPH=$(printf '%s\n' "$SRV" | awk '{n = split($1, a, ":"); print a[n]}')
setf "З'єднання з боку сервера (локальна -> віддалена кінцева точка):" "$SRV, стан ESTAB"
setf "З'єднання з боку контейнера (локальна -> віддалена кінцева точка):" "$NOD, стан ESTAB"
setf "Тимчасовий порт у цьому з'єднанні та на якому боці він використовується:" "$EPH — на боці сервера, тобто клієнта: його ядро виділило nc для вихідного з'єднання з діапазону net.ipv4.ip_local_port_range ($(sysctl -n net.ipv4.ip_local_port_range | tr '\t' '-')); у контейнері цей порт видно як віддалений"
nrun 'cat /tmp/nc5000.out'
here 'kill "$NCPID" 2>/dev/null; wait "$NCPID" 2>/dev/null; true'
ncap "pkill -f '^nc -l 5000'"

say "Завдання 3. HTTP"
runv CURL 'curl -sv -m 15 http://example.com/ -o /dev/null 2>&1 | grep -E "^[<>] " | head -n 20'
CURL=$(printf '%s\n' "$CURL" | tr -d '\r')
REQ=$(printf '%s\n' "$CURL" | grep -m 1 '^> GET')
RESP=$(printf '%s\n' "$CURL" | grep -m 1 '^< HTTP')
CT=$(printf '%s\n' "$CURL" | grep -i -m 1 '^< content-type:')
[ -n "$REQ" ] && setf "Рядок запиту до example.com:" "$REQ"
[ -n "$RESP" ] && setf "Рядок відповіді з кодом стану:" "$RESP"
[ -n "$CT" ] && setf "Значення Content-Type:" "${CT#< }"
nbg 'cd /tmp && python3 -m http.server 8000' /tmp/http8000.log
wait_listen 8000
run "curl -sv -m 5 http://$N_IP:8000/ -o /dev/null 2>&1 | grep -E '^[<>] (GET|HTTP)'"
run "curl -sv -m 5 http://$N_IP:8000/status -o /dev/null 2>&1 | grep -E '^[<>] (GET|HTTP)'"
C1=$(curl -s -o /dev/null -w '%{http_code}' -m 5 "http://$N_IP:8000/")
C2=$(curl -s -o /dev/null -w '%{http_code}' -m 5 "http://$N_IP:8000/status")
setf "Код стану звернення до кореневого шляху HTTP-сервера в контейнері:" "$C1 (OK — віддано HTML-список вмісту каталогу)"
setf "Код стану звернення до неіснуючого шляху:" "$C2 (File not found)"
nrunv HLOG 'cat /tmp/http8000.log'
CLI=$(printf '%s\n' "$HLOG" | grep -m 1 '"GET' | awk '{print $1}')
setf "Адреса клієнта, яку вивів HTTP-сервер у контейнері:" "$CLI — рядки вигляду «$CLI - - [дата] \"GET / HTTP/1.1\" 200 -» і «\"GET /status HTTP/1.1\" 404 -»"
ncap "pkill -f 'http.server 8000'"

say "Завдання 4. Сервер і клієнт робота"
nbg 'python3 -u ~/robot_server.py' /tmp/robot8.log
wait_listen 5000
runv R1 "python3 assets/robot_client.py $N_IP 5000 'MOVE 100'"
runv R2 "python3 assets/robot_client.py $N_IP 5000 'JUMP 5'"
setf "Відповідь сервера на команду MOVE 100:" "$(printf '%s\n' "$R1" | sed -n 's/^Відповідь: //p')"
setf "Непідтримувана команда і відповідь на неї:" "JUMP 5 → $(printf '%s\n' "$R2" | sed -n 's/^Відповідь: //p')"
here 'python3 assets/robot_client.py "$N_IP" 5000 "MOVE 100" --wait 12 > /tmp/c1.out 2>&1 & CA=$!; python3 assets/robot_client.py "$N_IP" 5000 "MOVE 200" --wait 12 > /tmp/c2.out 2>&1 & CB=$!'
sleep 3
nrunv S5 "ss -tan '( sport = :5000 )'"
S5LIVE=$(printf '%s\n' "$S5" | grep -E '^(LISTEN|ESTAB)')
setf "Кількість сокетів порту 5000 у контейнері під час роботи двох клієнтів:" "$(printf '%s\n' "$S5LIVE" | grep -c .)"
setf "Стани цих сокетів:" "$(printf '%s\n' "$S5LIVE" | awk '{print $1 " " $4 " ↔ " $5}' | paste -sd ';' - | sed 's/;/; /g')"
here 'wait "$CA" "$CB"; cat /tmp/c1.out /tmp/c2.out'
nrun 'cat /tmp/robot8.log'
ncap "pkill -f 'robot_server.py'"

say "Завдання 5. UDP і недоступний отримувач"
nbg 'nc -u -l 5001' /tmp/udp5001.out
sleep 1
nrunv U1 "ss -uan '( sport = :5001 )'"
run "printf 'line1\nline2\n' | nc -u -w1 $N_IP 5001"
sleep 1
nrunv U2 "ss -uan '( sport = :5001 )'"
nrun 'cat /tmp/udp5001.out'
ST1=$(printf '%s\n' "$U1" | awk 'NR > 1 {print $1; exit}')
ST2=$(printf '%s\n' "$U2" | awk 'NR > 1 {print $1 " (віддалена " $5 ")"; exit}')
setf "Стан UDP-сокета порту 5001 у контейнері:" "${ST1:-?} до першої датаграми; після першої — ${ST2:-?}: nc без -k робить connect() до першого відправника"
ncap "pkill -f 'nc -u -l 5001'"
sleep 1
runv RC "python3 assets/robot_client.py $N_IP 5000 'MOVE 100'"
runv RU "python3 assets/udp_sender.py $N_IP 5001 'hello'"
setf "Результат robot_client.py на TCP-порт 5000 без сервера:" "$RC (і рядок «… | помилка: …» у client.log)"
setf "Результат udp_sender.py на UDP-порт 5001 без отримувача:" "$RU — програма вважає відправлення успішним"
run 'tail -n 6 assets/client.log'

run_check "$L"
finish
