#!/usr/bin/env bash
# Практика 7 — інтерфейси, адреси, підмережа, сусіди, маршрути, DHCP, імена.
#   bash ~/labs-filled/lab07-run.sh
# Лог: ~/labs/lab-07-network/lab07-log.txt. Звіт: assets/network-report.txt. Змінює лише /etc/hosts контейнера.

. "$(dirname -- "$0")/lablib.sh"
L=$(labdir 07)
cd "$L" || exit 1
REPORT="$L/assets/network-report.txt"
start "$L/lab07-log.txt" "Практика 7. Мережа сервера й контейнера"
need_node

say "Завдання 1. Інтерфейси сервера"
run 'ip -br link'
run 'ip -br addr'
EXT_IF=$(ip -4 route show default | awk '{for (i = 1; i < NF; i++) if ($i == "dev") {print $(i + 1); exit}}')
run "ip -4 route show default"
run "ip link show $EXT_IF"
run "ip -4 addr show dev $EXT_IF"
run 'ip -4 addr show dev lxdbr0'
EXT_MAC=$(cat "/sys/class/net/$EXT_IF/address")
EXT_CIDR=$(ip -4 -o addr show dev "$EXT_IF" | awk '{print $4}' | head -n 1)
BR_CIDR=$(ip -4 -o addr show dev lxdbr0 | awk '{print $4}' | head -n 1)
BR_IP=${BR_CIDR%/*}
NOIP=$(comm -23 <(ip -br link | awk '{print $1}' | sed 's/@.*//' | sort) \
                <(ip -br -4 addr | awk '$3 != "" {print $1}' | sed 's/@.*//' | sort) | grep -v '^lo$' | grep '^veth' | head -n 1)
[ -n "$NOIP" ] || NOIP=$(comm -23 <(ip -br link | awk '{print $1}' | sed 's/@.*//' | sort) \
                <(ip -br -4 addr | awk '$3 != "" {print $1}' | sed 's/@.*//' | sort) | grep -v '^lo$' | head -n 1)
setf "Інтерфейси сервера та їхній стан:" "$(ip -br link | awk '{print $1 " " $2}' | sed 's/@[^ ]*//' | paste -sd ',' - | sed 's/,/, /g')"
setf "Назва зовнішнього інтерфейсу:" "$EXT_IF (через нього йде маршрут за замовчуванням)"
setf "MAC-адреса зовнішнього інтерфейсу:" "$EXT_MAC"
setf "IPv4-адреса й префікс зовнішнього інтерфейсу:" "$EXT_CIDR"
setf "IPv4-адреса й префікс мосту lxdbr0:" "$BR_CIDR"
setf "Інтерфейс із MAC-адресою, але без IPv4-адреси:" "${NOIP:-немає} — серверний кінець віртуального кабелю до контейнера: він лише підключений до мосту lxdbr0 і власної IP-адреси не потребує"

say "Завдання 2. Контейнер"
nrun 'hostname; ip -br link; ip -4 addr show dev eth0; ip link show eth0'
N_MAC=$(ncap 'cat /sys/class/net/eth0/address')
N_LINE=$(ncap 'ip -4 -o addr show dev eth0' | head -n 1)
N_CIDR=$(printf '%s\n' "$N_LINE" | awk '{print $4}')
N_IP=${N_CIDR%/*}
N_BRD=$(printf '%s\n' "$N_LINE" | awk '{for (i = 1; i < NF; i++) if ($i == "brd") print $(i + 1)}')
setf "Ім'я контейнера:" "$NODE"
setf "MAC-адреса інтерфейсу контейнера:" "$N_MAC"
setf "IPv4-адреса й префікс контейнера:" "$N_CIDR"
run "ping -c 4 $N_IP"
P1=$(ping -c 4 "$N_IP" 2>/dev/null | awk -F', ' '/transmitted/ {split($1, a, " "); split($2, b, " "); print a[1] " / " b[1] ", " $3}')
nrun "ping -c 4 $BR_IP"
P2=$(ncap "ping -c 4 $BR_IP" | awk -F', ' '/transmitted/ {split($1, a, " "); split($2, b, " "); print a[1] " / " b[1] ", " $3}')
setf "Результат перевірки зв'язку сервер -> контейнер (надіслано / отримано):" "$P1 (ping -c 4 $N_IP)"
setf "Результат перевірки зв'язку контейнер -> lxdbr0 (надіслано / отримано):" "$P2 (ping -c 4 $BR_IP)"

say "Завдання 3. Підмережа та тип адрес"
read -r NET FIRST LAST BCAST HOSTS PFX BRIN NPRIV EPRIV <<< "$(python3 - "$N_CIDR" "$BR_IP" "$EXT_CIDR" <<'PY'
import ipaddress, sys
iface = ipaddress.ip_interface(sys.argv[1]); net = iface.network
br = ipaddress.ip_address(sys.argv[2]); ext = ipaddress.ip_interface(sys.argv[3]).ip
def priv(ip):
    for r in ("10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16"):
        if ip in ipaddress.ip_network(r):
            return r
    return "-"
hosts = list(net.hosts())
print(net.network_address, hosts[0], hosts[-1], net.broadcast_address, net.num_addresses - 2,
      net.prefixlen, "так" if br in net else "ні", priv(iface.ip), priv(ext))
PY
)"
note "мережа $NET/$PFX, хости $FIRST – $LAST, broadcast $BCAST, хостів $HOSTS"
setf "Адреса мережі:" "$NET (префікс /$PFX)"
setf "Діапазон адрес для хостів:" "$FIRST – $LAST"
setf "Широкомовна адреса:" "$BCAST"
setf "Кількість адрес, які можна призначити хостам:" "$HOSTS (2^(32−$PFX) − 2: мінус адреса мережі й широкомовна)"
if [ "$N_BRD" = "$BCAST" ]; then
    setf "Чи збігається широкомовна адреса з полем brd:" "так — brd у ip -4 addr контейнера = $N_BRD"
else
    setf "Чи збігається широкомовна адреса з полем brd:" "ні — brd = ${N_BRD:-немає}, обчислено $BCAST"
fi
if [ "$BRIN" = так ]; then
    setf "Чи належить адреса lxdbr0 до цієї підмережі і чому:" "так — $BR_IP має ті самі перші $PFX біт, що й $N_IP, і лежить у діапазоні хостів $FIRST – $LAST; це шлюз цієї підмережі"
else
    setf "Чи належить адреса lxdbr0 до цієї підмережі і чому:" "ні — $BR_IP не входить до $NET/$PFX"
fi
priv_text() { if [ "$1" = - ]; then echo "не належить до приватних діапазонів RFC 1918"; else echo "$1 (RFC 1918)"; fi; }
setf "Приватний діапазон адреси контейнера:" "$(priv_text "$NPRIV")"
setf "Приватний діапазон адреси зовнішнього інтерфейсу сервера:" "$(priv_text "$EPRIV")"

say "Завдання 4. Таблиця сусідів"
run "ping -c 1 $N_IP > /dev/null; ip -4 neigh show dev lxdbr0"
NEIGH=$(ip -4 neigh show dev lxdbr0 | grep -m 1 "^$N_IP ")
setf "Запис контейнера в таблиці сусідів сервера:" "${NEIGH:-немає запису — повтори ping і ip -4 neigh}"
if printf '%s\n' "$NEIGH" | grep -qi "$N_MAC"; then
    setf "Чи збігається MAC-адреса в цьому записі з MAC-адресою інтерфейсу контейнера:" "так, це MAC eth0 контейнера ($N_MAC)"
fi
nrun 'ip -4 neigh'

say "Завдання 5. Маршрути"
run 'ip -4 route'
nrun 'ip -4 route'
run 'ip route get 8.8.8.8'
nrun 'ip route get 8.8.8.8'
setf "Шлюз за замовчуванням і інтерфейс сервера:" "$(ip -4 route show default | head -n 1)"
setf "Шлюз за замовчуванням і інтерфейс контейнера:" "$(ncap 'ip -4 route show default' | head -n 1) — шлюзом контейнера є сам сервер"
setf "Маршрут, обраний для 8.8.8.8 на сервері:" "$(ip route get 8.8.8.8 | head -n 1 | sed 's/ uid [0-9]*//; s/ *$//')"
setf "Маршрут, обраний для 8.8.8.8 у контейнері:" "$(ncap 'ip route get 8.8.8.8' | head -n 1 | sed 's/ uid [0-9]*//; s/ *$//')"
nrun 'timeout 60 tracepath -n -m 10 8.8.8.8'
HOP1=$(ncap 'timeout 30 tracepath -n -m 2 8.8.8.8' | awk '$1 == "1:" {print $2; exit}')
setf "Адреса першого кроку tracepath з контейнера:" "${HOP1:-немає відповіді}"

say "Завдання 6. DHCP"
nrun 'ip -4 addr show dev eth0'
N_LFT=$(ncap 'ip -4 addr show dev eth0' | grep -o 'valid_lft [^ ]*' | head -n 1)
if [ "$N_LFT" = "valid_lft forever" ]; then
    setf "Строк дії адреси контейнера (valid_lft):" "valid_lft forever — адресу задано статично, не через DHCP"
else
    setf "Строк дії адреси контейнера (valid_lft):" "${N_LFT:-не знайдено} — секунди до кінця оренди DHCP"
fi
run "ip -4 addr show dev $EXT_IF"
E_ADDR=$(ip -4 addr show dev "$EXT_IF")
E_LFT=$(printf '%s\n' "$E_ADDR" | grep -o 'valid_lft [^ ]*' | head -n 1)
if printf '%s\n' "$E_ADDR" | grep -q ' dynamic '; then
    setf "Чи отримує автоматично адресу зовнішній інтерфейс сервера:" "так — біля $EXT_IF теж є dynamic, $E_LFT"
else
    setf "Чи отримує автоматично адресу зовнішній інтерфейс сервера:" "ні — позначки dynamic немає, $E_LFT (адресу задано статично)"
fi

say "Завдання 7. Імена"
run 'hostname'
nrun 'hostname'
setf "Ім'я хоста сервера:" "$(hostname)"
setf "Ім'я хоста контейнера:" "$(ncap hostname)"
nrun 'getent hosts example.com; getent ahostsv4 example.com | head -n 1'
nrun 'dig example.com A'
nrun 'nslookup example.com'
EX_IP=$(ncap 'getent ahostsv4 example.com' | awk '{print $1; exit}')
DIG=$(ncap 'dig example.com A')
TTL=$(printf '%s\n' "$DIG" | awk '/ANSWER SECTION/ {f = 1; next} f && $4 == "A" {print $2; exit}')
SRV=$(printf '%s\n' "$DIG" | grep -m 1 '^;; SERVER:' | sed 's/^;; SERVER: //')
setf "IPv4-адреса example.com:" "${EX_IP:-не визначено}"
setf "TTL запису з виводу dig:" "${TTL:+$TTL с}${TTL:-не знайдено (DNS не відповів)}"
setf "Значення поля SERVER з виводу dig:" "${SRV:-не знайдено}"
nrun "grep -qE '[[:space:]]server\$' /etc/hosts || echo '$BR_IP server' >> /etc/hosts; tail -n 3 /etc/hosts"
nrun 'getent hosts server'
nrun 'dig server A'
nrun 'ping -c 2 server'
setf "Запис, доданий до /etc/hosts контейнера:" "$(ncap "grep -E '[[:space:]]server\$' /etc/hosts | tail -n 1")"
setf "Результат визначення адреси імені server засобами системи:" "$(ncap 'getent hosts server')"
DS=$(ncap 'dig server A' | grep -m 1 'status:' | sed 's/.*status: \([A-Z]*\).*/\1/')
DA=$(ncap 'dig +short server A' | grep -E '^[0-9.]+$' | paste -sd ' ' -)
setf "Результат запиту імені server через dig:" "status: ${DS:-?}, ANSWER SECTION: ${DA:-відсутня}"

run_check "$L"
finish
