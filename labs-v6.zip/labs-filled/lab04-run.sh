#!/usr/bin/env bash
# Практика 4 — змінні середовища, setup_robot.sh, сигнали, PATH.   bash ~/labs-filled/lab04-run.sh
# Працює в ~/labs/lab-04. Лог: ~/labs/lab-04/lab04-log.txt. Окремого звіту в лабі немає — здається setup_robot.sh.

. "$(dirname -- "$0")/lablib.sh"
L=$(labdir 04)
cd "$L" || exit 1
start "$L/lab04-log.txt" "Практика 4. Bash-скрипт setup_robot.sh"
for f in setup_robot.sh robot.py set-env.sh; do
    [ -f "$f" ] || { echo "Немає $L/$f — запусти bash ~/labs-filled/deploy.sh" >&2; exit 1; }
done
chmod +x setup_robot.sh

say "Завдання 1. Область видимості змінних"
run 'set +u; unset ROBOT_ENV; ROBOT_ENV=testing; echo "поточний shell: [$ROBOT_ENV]"; bash -c '\''echo "дочірній bash до export: [$ROBOT_ENV]"'\''; export ROBOT_ENV; bash -c '\''echo "дочірній bash після export: [$ROBOT_ENV]"'\'''
run 'cat set-env.sh'
run 'set +u; unset ROBOT_COLOR; bash set-env.sh; echo "після bash set-env.sh: [$ROBOT_COLOR]"; source ./set-env.sh; echo "після source set-env.sh: [$ROBOT_COLOR]"'
note "Пояснення: без export змінна живе лише в поточному shell; дочірній процес отримує тільки змінні середовища."
note "bash set-env.sh виконує файл у дочірньому bash — змінна зникає разом із ним; source — у поточному shell."

say "Завдання 2–3. Перевірка setup_robot.sh"
run 'bash -n setup_robot.sh && echo "синтаксис OK"'
run 'grep -n TODO setup_robot.sh || echo "TODO немає"'
run './setup_robot.sh; echo "код: $?"'
run './setup_robot.sh unknown; echo "код: $?"'
run './setup_robot.sh development extra; echo "код: $?"'

say "Завдання 4–5. Запуск і зупинка сигналом"
here './setup_robot.sh development & SETUP_PID=$!; echo "SETUP_PID=$SETUP_PID"'
sleep 3
run 'cat runtime/development/robot.pid; ps -o pid,ppid,stat,cmd -p "$(cat runtime/development/robot.pid)"'
here 'kill -TERM "$SETUP_PID"; wait "$SETUP_PID"; echo "код: $?"'
run 'tail -n 5 runtime/development/logs/robot.log'
run 'cat runtime/development/logs/robot-error.log'
run 'cat runtime/development/config/robot.conf'
run 'find runtime -maxdepth 3 | sort'
run 'ps -p "$(cat runtime/development/robot.pid)" > /dev/null && echo "robot.py ще працює!" || echo "robot.py не працює — зупинено коректно"'

say "Перевірка: шляхи від каталогу скрипту, а не від поточного"
here 'cd /tmp; "$L/setup_robot.sh" development & P2=$!; sleep 2; kill -TERM "$P2"; wait "$P2"; echo "код: $?"; cd "$L"'
cd "$L" || exit 1
run 'ls /tmp/runtime 2>/dev/null && echo "runtime у /tmp — погано" || echo "у /tmp runtime не створено — шляхи правильні"'

say "Додаткове завдання. bin/ і PATH"
run 'mkdir -p bin && ln -sfn ../setup_robot.sh bin/setup-robot && ls -l bin/'
here 'export PATH="$HOME/labs/lab-04/bin:$PATH"; command -v setup-robot'
here 'setup-robot production & P3=$!; sleep 2; kill -TERM "$P3"; wait "$P3"; echo "код: $?"'
run 'cat runtime/production/config/robot.conf; find runtime -maxdepth 1 | sort'

finish
