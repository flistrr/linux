#!/usr/bin/env bash
# Практика 10 — аудит портів, firewall контейнера, діагностика «клієнт не бачить сервер», tcpdump.
#   bash ~/labs-filled/lab10-run.sh
# Лог: ~/labs/lab-10-firewall/lab10-log.txt. Звіт: assets/firewall-report.txt. Клієнт пише assets/client.log.
# Firewall змінюється ЛИШЕ в контейнері. Наприкінці: ufw увімкнено (SSH + 5000/tcp), сервер команд працює.

. "$(dirname -- "$0")/lablib.sh"
L=$(labdir 10)
cd "$L" || exit 1
REPORT="$L/assets/firewall-report.txt"
start "$L/lab10-log.txt" "Практика 10. Firewall і діагностика"
need_node
N_IP=$(node_ip); BR_IP=$(br_ip)
A10=/home/shared/labs/lab-10-firewall/assets
note "контейнер: $N_IP, сервер у lxdbr0: $BR_IP"
CLIENT="python3 assets/robot_client.py $N_IP 5000 'MOVE 100'"
one_line() { printf '%s\n' "$1" | grep -v '^$' | paste -sd '|' - | sed 's/|/ \/ /g'; }

say "Завдання 1. Аудит відкритих портів"
nrun 'ss -tulpn'
nrun 'lsof -i -P -n | grep -E "LISTEN|UDP"'
SS=$(ncap 'ss -Htulpn')
setf_list=$(printf '%s\n' "$SS" | awk '{p = $7; sub(/^users:\(\("/, "", p); sub(/".*/, "", p); print $1 " " $5 " — " (p == "" ? "?" : p)}' | sort -u)
[ -n "$setf_list" ] && blockf "Сокети очікування в контейнері (протокол, адреса й порт, програма):" "$setf_list"
EXP=$(printf '%s\n' "$SS" | awk '$1 == "tcp" && $5 !~ /^(127\.|\[::1\])/ && $5 !~ /:22$/' | head -n 1)
if [ -n "$EXP" ]; then
    E_ADDR=$(printf '%s\n' "$EXP" | awk '{print $5}')
    E_PORT=${E_ADDR##*:}; E_HOST=${E_ADDR%:*}
    E_PROG=$(printf '%s\n' "$EXP" | grep -o '"[^"]*"' | head -n 1 | tr -d '"')
    E_PID=$(printf '%s\n' "$EXP" | grep -o 'pid=[0-9]*' | head -n 1 | cut -d= -f2)
    nrunv ST "systemctl status $E_PID --no-pager -n 0"
    E_UNIT=$(printf '%s\n' "$ST" | head -n 1 | grep -o '[^ ]*\.service' | head -n 1)
    setf "Зайва служба: програма, порт і адреса прослуховування:" "$E_PROG, TCP $E_PORT, $E_HOST (усі адреси)"
    setf "Unit цієї служби:" "$E_UNIT"
    setf "Як визначено unit за процесом:" "PID $E_PID узято з ss -tulpn (users:((\"$E_PROG\",pid=$E_PID,…))), потім systemctl status $E_PID — перший рядок показує unit, до якого належить процес (● $E_UNIT). Вимкнено: systemctl disable --now $E_UNIT; перевірка: ss -tlnp | grep $E_PORT — порожньо, systemctl is-enabled → disabled."
    nrun "systemctl disable --now $E_UNIT; sleep 1; ss -tlnp | grep ':$E_PORT ' || echo 'порт $E_PORT більше не прослуховується'; systemctl is-enabled $E_UNIT; systemctl is-active $E_UNIT"
else
    note "Зайвої служби, доступної з мережі, не знайдено (уже вимкнена при попередньому запуску?)"
    nrun 'systemctl is-enabled robot-telemetry.service; systemctl is-active robot-telemetry.service; true'
fi

say "Завдання 2. Firewall контейнера"
if ncap 'ufw status' | grep -q 'Status: active'; then
    note "(повторний запуск: firewall уже ввімкнено — скидаю правила, щоб пройти завдання з початку)"
    nrun 'ufw --force reset'
fi
nrun 'ufw status verbose'
nrun 'ufw default deny incoming; ufw allow ssh; ufw status verbose'
nrun 'ufw --force enable; ufw status verbose'
DEF=$(ncap 'ufw status verbose' | grep '^Default:')
setf "Політика вхідного трафіку після налаштування:" "$(printf '%s\n' "$DEF" | grep -o '[a-z]* (incoming)' | cut -d' ' -f1) — у ufw status verbose: «$DEF»"
nbg 'cd /tmp && python3 -m http.server 8000' /tmp/http10.log
wait_listen 8000
runv P22 "nc -vz -w 3 $N_IP 22"
runv P0 "nc -vz -w 3 $N_IP 8000"
setf "Результат nc -vz до порту 8000 після ввімкнення firewall:" "$P0 — пакет мовчки відкинуто політикою deny (порт 22 при цьому: $P22)"
nrun 'ufw allow 8000/tcp; ufw status numbered'
runv P1 "nc -vz -w 3 $N_IP 8000"
setf "Результат nc -vz до порту 8000 після правила дозволу:" "$P1"
nrun 'ufw delete allow 8000/tcp; ufw deny 8000/tcp; ufw status numbered'
runv P2 "nc -vz -w 3 $N_IP 8000"
setf "Результат nc -vz до порту 8000 після заміни правилом заборони:" "$P2 — ufw deny відкидає пакет (DROP) без відповіді"
nrunv IPT 'iptables -S ufw-user-input'
nrun 'iptables -L ufw-user-input -n -v'
setf "Рядок iptables -S для правила ufw щодо порту 22:" "$(printf '%s\n' "$IPT" | grep -m 1 -- '--dport 22 ')"
setf "Рядок iptables -S для правила ufw щодо порту 8000:" "$(printf '%s\n' "$IPT" | grep -m 1 -- '--dport 8000 ')"
nrun 'for n in $(ufw status numbered | grep -E "^\[ *[0-9]+\] 8000/tcp" | sed -E "s/^\[ *([0-9]+)\].*/\1/" | sort -rn); do ufw --force delete "$n"; done; ufw status numbered'
runv P3 "nc -vz -w 3 $N_IP 8000"
setf "Результат nc -vz до порту 8000 після видалення правила:" "$P3 — знову діє політика deny (incoming)"
ncap "pkill -f 'http.server 8000'"

say "Завдання 3. Клієнт не бачить сервер"
ncap "pkill -f 'robot_server.py'"
nrun "bash $A10/start-robot.sh"
wait_listen 5000
runv M1 "$CLIENT"
setf "Перше повідомлення клієнта:" "$(one_line "$M1")"
if printf '%s\n' "$M1" | grep -q 'timed out'; then
    note "timed out → пакети губляться дорогою → дивимось firewall контейнера:"
    nrun 'ufw status numbered'
    nrun 'ufw allow 5000/tcp; ufw status numbered'
else
    note "УВАГА: очікувався timed out, а клієнт повідомив інше — звір рядки «Перевірка…» у звіті з логом"
fi
runv M2 "$CLIENT"
setf "Повідомлення клієнта після першого виправлення:" "$(one_line "$M2")"
nrunv LS "ss -tlnp '( sport = :5000 )'"
if printf '%s\n' "$LS" | grep -q '127.0.0.1:5000'; then
    note "refused, а сервер слухає 127.0.0.1:5000 → перезапускаємо його на 0.0.0.0 (фоновий процес завершуємо за PID):"
    nrun 'P=$(pgrep -f "robot_server.py 5000 --bind 127.0.0.1"); echo "PID фонового сервера: $P"; kill $P'
    nbg "python3 $A10/robot_server.py 5000 --bind 0.0.0.0" /tmp/robot10.log
    wait_listen 5000
fi
runv M3 "$CLIENT"
setf "Повідомлення клієнта після другого виправлення:" "$(one_line "$M3")"
nrun "pkill -f 'robot_server.py 5000 --bind 0.0.0.0'; sleep 1; ss -tln '( sport = :5000 )'"
runv M4 "$CLIENT"
setf "Повідомлення клієнта після зупинки сервера:" "$(one_line "$M4") — firewall порт уже пропускає, але процесу на ньому немає, тож ядро відповідає RST (раніше, з firewall, був timed out)"
nbg "python3 $A10/robot_server.py 5000 --bind 0.0.0.0" /tmp/robot10.log
wait_listen 5000
run 'tail -n 6 assets/client.log'

say "Завдання 4. TCP-з'єднання в захопленому трафіку"
nbg 'timeout 40 tcpdump -i eth0 -n -w /root/handshake.pcap tcp port 5000' /tmp/tcpdump.log
sleep 3
runv M5 "$CLIENT"
sleep 1
ncap 'pkill -INT -x tcpdump'
sleep 1
nrunv TD 'tcpdump -n -r /root/handshake.pcap 2>/dev/null'
HS=$(printf '%s\n' "$TD" | head -n 3)
blockf "Три рядки встановлення з'єднання (адреси, порти, прапорці):" "$HS
(далі [P.] з командою «MOVE 100» від сервера, [P.] з «OK MOVE 100» від контейнера)"
FSRC=$(printf '%s\n' "$TD" | grep -m 1 'Flags \[F' | awk '{print $3}')
case "$FSRC" in
    "$BR_IP".*) : ;;   # клієнт на сервері закрив першим — як і записано у звіті
    "") note "  (пакета FIN у захопленні не знайдено)" ;;
    *) setf "Хто першим почав завершення з'єднання і за яким прапорцем це видно:" "$FSRC — перший пакет [F.] надіслав цей бік" ;;
esac

run_check "$L"
finish
