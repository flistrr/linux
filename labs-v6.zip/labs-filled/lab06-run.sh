#!/usr/bin/env bash
# Практика 6 — автозапуск, журнали journald, текстові журнали, таймер, прибирання.
#   bash ~/labs-filled/lab06-run.sh          (після lab05-run.sh; триває ~3–4 хв через таймер)
# Лог: ~/labs/lab-06-journal/lab06-log.txt. Звіт: ~/labs/lab-06-journal/journal-report.txt.

. "$(dirname -- "$0")/lablib.sh"
L=$(labdir 06)
REPORT="$L/journal-report.txt"
UDIR="$HOME/.config/systemd/user"
UNIT="$UDIR/robot.service"
STATUS_LOG="$HOME/labs/lab-06-journal/status.log"
start "$L/lab06-log.txt" "Практика 6. Журнали й таймер"
[ -f "$UNIT" ] || { echo "Немає $UNIT — спершу bash ~/labs-filled/lab05-run.sh" >&2; exit 1; }
need_sudo
systemctl --user is-active --quiet robot || run 'systemctl --user start robot'
sleep 3

say "Завдання 1. Автозапуск служби"
run 'systemctl --user enable robot'
run 'ls -l ~/.config/systemd/user/default.target.wants/'
TGT=$(readlink "$UDIR/default.target.wants/robot.service")
[ -n "$TGT" ] && setf "Ціль цього посилання:" "$TGT   (ls -l ~/.config/systemd/user/default.target.wants/)"
run 'systemctl --user disable robot'
run 'ls -l ~/.config/systemd/user/default.target.wants/ 2>&1; systemctl --user is-active robot'

say "Завдання 2. Журнал власної служби"
run 'journalctl --user-unit robot -n 20 --no-pager'
run 'journalctl --user-unit robot -n 5 -o short-iso --no-pager'
TS=$(journalctl --user-unit robot -n 1 -o short-iso --no-pager -q | tail -n 1 | awk '{print $1}')
[ -n "$TS" ] && setf "Вигляд часової мітки з опцією -o short-iso:" "$TS — дата, «T», час і зсув від UTC за ISO 8601"
note "(режим -f показує нові записи наживо; вихід — Ctrl+C. Тут — 5 секунд:)"
run 'timeout 5 journalctl --user-unit robot -f --no-pager; true'
run "journalctl --user-unit robot -n 8 -o json-pretty --no-pager | grep -E '\"(MESSAGE|PRIORITY)\"'"
prio() {   # prio <текст у повідомленні> → PRIORITY останнього такого запису
    journalctl --user-unit robot -n 60 -o json --no-pager 2>/dev/null | python3 -c '
import json, sys
want, last = sys.argv[1], ""
for line in sys.stdin:
    try:
        d = json.loads(line)
    except ValueError:
        continue
    if isinstance(d.get("MESSAGE"), str) and want in d["MESSAGE"]:
        last = d.get("PRIORITY", "")
print(last)' "$1"
}
P_OUT=$(prio "цикл"); P_ERR=$(prio "діагностичний")
[ -n "$P_OUT" ] && setf "Пріоритет (PRIORITY) записів, які програма вивела у стандартний вивід:" "$P_OUT (info)"
[ -n "$P_ERR" ] && setf "Пріоритет (PRIORITY) записів, які програма вивела у стандартний потік помилок:" "$P_ERR (info)$([ "$P_OUT" = "$P_ERR" ] && echo ' — такий самий, як для stdout')"

run 'journalctl --user-unit robot -p warning -n 15 --no-pager'
B_ALL=$(journalctl --user-unit robot -p warning -q --no-pager | wc -l)
B_REG=$(journalctl --user-unit robot -p warning -q --no-pager | grep -c -E 'цикл|діагностичний')
B_EX=$(journalctl --user-unit robot -p warning -q --no-pager | tail -n 1 | sed 's/^.*: //')
grep -q '^SyslogLevel=' "$UNIT" || run "sed -i '/^ExecStart=/a SyslogLevel=warning' $UNIT"
run "cat $UNIT"
run 'systemctl --user daemon-reload'
run 'systemctl --user restart robot'
sleep 12
run 'journalctl --user-unit robot -p warning -n 10 --no-pager'
A_REG=$(journalctl --user-unit robot -p warning -q --no-pager | grep -c -E 'цикл|діагностичний')
P_NEW=$(prio "цикл")
setf "Результат команди з опцією -p warning до зміни unit-файла:" "записів: $B_ALL, з них «цикл N»/«діагностичний запис N»: $B_REG — звичайні повідомлення фільтр не пройшли; видно лише записи збоїв із практики 5 і повідомлення systemd про збої служби (останній: «${B_EX:-немає}»)"
setf "Результат тієї самої команди після додавання SyslogLevel=warning:" "з'явилися рядки «robot: цикл N» і «robot: діагностичний запис N» (за ~12 с: $((A_REG - B_REG))) — тепер вони збережені з PRIORITY=${P_NEW:-4} (warning)"

say "Завдання 3. Фільтрація системного журналу"
run 'sudo journalctl -b -n 20 --no-pager'
run 'sudo journalctl --since "15 min ago" -n 20 --no-pager'
run 'sudo journalctl -b -p err -n 20 --no-pager'
ERRN=$(sudo journalctl -b -p err -q --no-pager | wc -l)
setf "Кількість записів рівня помилки від останнього завантаження:" "$ERRN"
note "(свіжий запис ssh: спроба входу на localhost без пароля — вона завершиться відмовою, це нормально)"
run 'ssh -o BatchMode=yes -o StrictHostKeyChecking=accept-new -o ConnectTimeout=5 localhost true; true'
sleep 1
run 'sudo journalctl -u ssh -n 20 --no-pager'
SSHREC=$(sudo journalctl -u ssh -n 50 --no-pager -q | grep -E 'Accepted|Connection closed|Disconnected|Server listening|Received disconnect' | tail -n 1)
[ -n "$SSHREC" ] || SSHREC=$(sudo journalctl -u ssh -n 1 --no-pager -q)
[ -n "$SSHREC" ] && setf "Один запис служби ssh:" "$SSHREC"

say "Завдання 4. Текстові журнали"
run 'ls -l /var/log'
THREE=$(for f in auth.log syslog journal kern.log dpkg.log apt; do [ -e "/var/log/$f" ] && echo "$f"; done | head -n 3 | paste -sd ',' - | sed 's/,/, /g')
setf "Три файли або каталоги з /var/log:" "$THREE"
if sudo test -f /var/log/auth.log; then
    run 'sudo grep -a sshd /var/log/auth.log | tail -n 5'
    AUTHREC=$(sudo grep -a 'sshd' /var/log/auth.log | tail -n 1)
    if [ -n "$AUTHREC" ]; then
        setf "Запис із /var/log/auth.log:" "$AUTHREC"
        MSG=${AUTHREC#*]: }
        JREC=$(sudo journalctl -q --no-pager -t sshd -t sshd-session -n 300 | grep -F -- "$MSG" | tail -n 1)
        run "sudo journalctl -q --no-pager -t sshd -t sshd-session -n 300 | grep -F -- $(printf '%q' "$MSG") | tail -n 1"
        [ -n "$JREC" ] && setf "Той самий запис у виводі journalctl:" "$JREC (текст повідомлення однаковий, відрізняється формат часової мітки)"
    fi
else
    note "  /var/log/auth.log немає (не встановлено rsyslog) — запусти make-stand.sh ще раз"
fi

say "Завдання 5. Таймер"
if [ ! -x "$HOME/labs/lab-06-journal/collect-status.sh" ]; then
    echo "Немає виконуваного ~/labs/lab-06-journal/collect-status.sh — запусти deploy.sh" >&2; exit 1
fi
for u in status.service status.timer; do
    [ -f "$UDIR/$u" ] && ! cmp -s "$LF/lab-06-journal/systemd-user/$u" "$UDIR/$u" && cp "$UDIR/$u" "$UDIR/$u.bak"
    cp "$LF/lab-06-journal/systemd-user/$u" "$UDIR/$u"
done
run "cat $UDIR/status.service $UDIR/status.timer"
run 'systemctl --user daemon-reload'
run 'systemctl --user start status.service'
run "cat $STATUS_LOG"
run 'systemctl --user enable --now status.timer'
sleep 2
run 'systemctl --user list-timers --no-pager'
read -r NEXT LEFT <<< "$(systemctl --user list-timers --no-pager status.timer 2>/dev/null | python3 -c '
import re, sys
for line in sys.stdin:
    if "status.timer" in line:
        m = re.match(r"^(\w{3} \S+ \S+ \S+|-|n/a)\s+(.+?)\s+(\w{3} \S+ \S+ \S+|-|n/a)\s+", line)
        if m:
            print(m.group(1).replace(" ", "_"), m.group(2).replace(" ", "_"))
        break')"
[ -n "${NEXT:-}" ] && setf "Значення поля NEXT для status.timer:" "${NEXT//_/ }"
[ -n "${LEFT:-}" ] && setf "Значення поля LEFT для status.timer:" "${LEFT//_/ }"
note "Чекаю, поки в status.log буде ≥ 2 записи з різним часом (до 2,5 хв)…"
for i in $(seq 30); do
    n=$(cut -c1-19 "$STATUS_LOG" 2>/dev/null | sort -u | wc -l)
    [ "$n" -ge 2 ] && break
    sleep 5
done
run "cat $STATUS_LOG"
setf "Кількість записів у status.log наприкінці заняття:" "$(wc -l < "$STATUS_LOG")"

say "Завдання 6. Прибирання"
run 'systemctl --user disable --now status.timer robot'
run 'systemctl --user list-timers --no-pager'
run 'systemctl --user is-active robot status.timer; true'

run_check "$L"
finish
